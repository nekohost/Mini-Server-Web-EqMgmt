/* [MINI-COMMENT: SCREEN.REVIEW.SAMPLE.DATA]
 * [EN rev.2]
 * [Role] Supplies synthetic read-only states to the unmodified candidate UI for screenshot review.
 * [Dependencies] Current Jinja/JS/CSS, a loopback fixture and SCENE injected by the renderer.
 * [Impact] No business mutation, real model request, secret or product-style override is introduced.
 */
(function () {
    'use strict';
    const scene = window.SCREEN_SCENE, cid = 'a'.repeat(32), jid = 'b'.repeat(32);
    localStorage.setItem('theme', scene.theme);
    const source = { provider_name: 'Strata PC A', model_label: 'Qwen3.8 Flash Next', revision: 1, reasoning_effort: 'medium' };
    const storage = { base_chars: 32000000, extension_chars: 32000000, total_chars: 64000000, used_chars: scene.state === 'recovery' ? 32001200 : 18240, reserved_chars: 458912, above_base: scene.state === 'recovery' };
    const models = [
        { id: '1'.repeat(32), provider: 'Strata PC A', label: 'Qwen3.8 Flash Next', available: true, tools: true, levels: ['low','medium','high'] },
        { id: '2'.repeat(32), provider: 'Strata PC B', label: 'Qwen3.8 Flash Next', available: true, tools: true, levels: ['low','medium','high'] },
        { id: '3'.repeat(32), provider: '로컬 모델 PC', label: 'Qwen3.5 4B', available: true, tools: false, levels: [] }
    ];
    const titles = [{ id: cid, title: scene.state === 'switch' ? '같은 대화에서 모델 바꾸기' : '업무용 노트북 등록', updated: 3 },
        { id: 'c'.repeat(32), title: '보증 기간이 다가오는 장비', updated: 2 }, { id: 'd'.repeat(32), title: '새 제조사 등록 신청', updated: 1 }];
    const reasoning = '먼저 요청한 장비가 본인 소유인지 확인합니다.\n승인된 모델과 옵션을 조회한 다음, 이름·시리얼·구입일을 대조합니다.\n실제 등록은 확인 카드의 실행 버튼을 누르기 전까지 진행하지 않습니다.';
    const answer = scene.state === 'switch' ? '**앞선 작업을 이어갈 수 있습니다.**\n노트북 등록 내용과 아직 확인하지 않은 항목은 이 대화에 보관되어 있습니다.\n현재 선택한 모델은 대화 전용이므로, 장비 업무를 이어가려면 업무 가능 모델을 선택해 주세요.' :
        '**등록할 장비 정보를 정리했습니다.**\n업무용 노트북의 모델·시리얼·구입일을 확인했습니다.\n아래 내용을 검토한 뒤 실행을 누르면 등록됩니다. 아직 적용하지 않았습니다.';
    const states = { thinking: 'running', review: 'waiting_confirmation', switch: 'done', recovery: 'recovery_required' };
    const currentState = states[scene.state] || 'done';
    const stopReason = scene.state === 'recovery' ? 'AI 연결이 중단되어 이전 요청의 종료를 확인하지 못했습니다. 같은 장비를 중복 등록하지 않도록 이 대화의 새 요청을 보류합니다. 관리자에게 종료 확인을 요청해 주세요.' : null;
    const pending = { id: 'e'.repeat(32), job: jid, operation: 'equipment_create', payload: JSON.stringify({ name: '업무용 노트북', option_id: 17, serial_number: 'SAMPLE-NB-001', purchase_date: '2026-10-15', warranty_end_date: '2027-10-14', memo: '업무용 장비 · 샘플 데이터', is_public: false, is_draft: false }), before_json: JSON.stringify({ _selected_option: { id: 17, official_model_name: '샘플 업무용 노트북', option_name: '16GB / 512GB' } }), expires: 4102444800, state: 'pending', result: null };
    const profile = JSON.stringify({ chat: true, tools: true, levels: ['low','medium','high'] });
    const providerA = { id: '5'.repeat(32), name: 'Strata PC A', revision: 1, enabled: 1, retired: 0, manual: 0, sort_order: 0, base_url: 'http://192.0.2.10:8080/v1', adapter: 'strata', resource_group: '7'.repeat(32), has_key: 1, last_checked: 1793764800, last_error: null,
        models: [{ id: '1'.repeat(32), upstream: 'qwen3.8-flash-next', label: 'Qwen3.8 Flash Next', published: 1, present: 1, manual: 0, sort_order: 0, context_tokens: 65536, profile, verified_revision: 1 },
            { id: '4'.repeat(32), upstream: 'qwen3.5-4b', label: 'Qwen3.5 4B · 대화용', published: 1, present: 1, manual: 0, sort_order: 1, context_tokens: 32768, profile: JSON.stringify({ chat: true, tools: false, levels: [] }), verified_revision: 1 }] };
    const providerB = { ...providerA, id: '6'.repeat(32), name: 'Strata PC B', base_url: 'http://192.0.2.11:8080/v1', resource_group: '8'.repeat(32), has_key: 0, models: [] };
    window.SCREEN_ERRORS = [];
    addEventListener('error', e => window.SCREEN_ERRORS.push(String(e.message || e.type)));
    addEventListener('unhandledrejection', e => window.SCREEN_ERRORS.push(String(e.reason && e.reason.message || e.reason)));
    const nativeFetch = window.fetch.bind(window);
    window.fetch = async function (path, options = {}) {
        const url = new URL(path, location.origin);
        if (url.origin !== location.origin) throw Error('Screenshot fixture forbids external requests');
        if (!url.pathname.startsWith('/api/')) return nativeFetch(path, options);
        if (options.method && options.method !== 'GET') throw Error('Screenshot fixture is read-only');
        let data = { success: true };
        if (url.pathname === '/api/check_session') data = { valid: true };
        else if (url.pathname === '/api/user_settings') data.settings = { theme: scene.theme, layout_skin: 'standard' };
        else if (url.pathname === '/api/admin/ai/providers') Object.assign(data, { providers: [providerA,providerB], groups: [{ id: '7'.repeat(32), name: 'PC A · 단일 GPU' }, { id: '8'.repeat(32), name: 'PC B · 단일 GPU' }], default_model: '1'.repeat(32), encryption_configured: true });
        else if (url.pathname.endsWith('/capabilities')) Object.assign(data, { storage, writes: true, file_tools: true, scopes: ['my','public','draft'], tools: ['search_equipment','prepare_equipment_create','prepare_catalog_request'] });
        else if (url.pathname === '/api/ai/models') Object.assign(data, { models, default_model: models[0].id });
        else if (url.pathname === '/api/ai/conversations') Object.assign(data, { conversations: scene.state === 'welcome' ? [] : titles, next_cursor: null });
        else if (url.pathname.endsWith('/messages')) Object.assign(data, { storage, conversation: { id: cid, title: titles[0].title, selection_id: scene.state === 'switch' ? models[2].id : models[0].id, next_level: scene.state === 'switch' ? 'low' : 'medium', selection_revision: 1 }, next_before: null,
            messages: [{ id: 1, role: 'user', job: jid, reasoning: '', content: scene.state === 'switch' ? '모델을 바꿔도 이 장비 등록 작업을 이어갈 수 있을까요?' : '업무용 노트북을 등록해 주세요. 시리얼은 SAMPLE-NB-001이고 구입일은 10월 15일입니다.' },
                { id: 2, role: 'assistant', job: jid, reasoning, content: scene.state === 'thinking' ? '' : scene.state === 'recovery' ? '승인된 옵션과 장비 정보를 확인하고 있습니다.' : answer }],
            jobs: [{ id: jid, state: currentState, steps: scene.state === 'thinking' ? 0 : 1, level: 'medium', source, position: null, error: stopReason, error_code: stopReason ? 'STREAM_INCOMPLETE' : null, answer_started: scene.state !== 'thinking' }],
            proposals: scene.state === 'review' ? [pending] : [] });
        else if (url.pathname.includes('/api/ai/jobs/')) Object.assign(data, { storage, id: jid, message_id: 2, state: currentState, source, steps: 0, generation: 1, error: stopReason, worker_stale: false, position: null,
            reasoning: '', content: '', r: Number(url.searchParams.get('r') || reasoning.length), c: Number(url.searchParams.get('c') || 0), content_length: 0, reasoning_length: reasoning.length, proposals: [], answer_started: false });
        else Object.assign(data, { menus: [], settings: {} });
        return new Response(JSON.stringify(data), { status: 200, headers: { 'Content-Type': 'application/json', 'X-Assistant-Account': 'synthetic-screen-review-account' } });
    };
})();

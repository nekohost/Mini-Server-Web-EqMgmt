"""[MINI-COMMENT: SCREEN.REVIEW.CAPTURE]
[EN rev.1]
[Role] Captures source-driven AI UI samples on the authorized Linux host and preserves new PNG artifacts.
[Dependencies] Local source reads, SSH, existing Linux Flask/Chromium and synthetic read-only browser responses.
[Impact] Never runs the Staging app on Windows or opens a real model/database; existing files are not overwritten.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys
import zlib

REMOTE = r'''
import base64,json,sys,tempfile,threading,subprocess,re,html,time
from pathlib import Path
from flask import Flask,Response,request
from jinja2 import DictLoader
from werkzeug.serving import make_server,WSGIRequestHandler
payload=json.loads(__import__('zlib').decompress(base64.b64decode(PAYLOAD)))
assets=payload['assets']
app=Flask('screen_review',static_folder=None)
app.secret_key='synthetic-screen-only-key-not-used-for-real-auth'
app.jinja_loader=DictLoader({p[10:]:v for p,v in assets.items() if p.startswith('templates/')})

class Quiet(WSGIRequestHandler):
    def log_request(self,*_):
        """[Role] Suppresses static request noise. [Dependencies] Fixture WSGI server. [Impact] Keeps JSON output bounded."""
        pass

@app.get('/static/<path:filename>',endpoint='static')
def static(filename):
    """[Role] Serves packed source assets. [Dependencies] Local-source payload. [Impact] No production filesystem fallback."""
    value=assets.get('static/'+filename)
    return Response(value,status=200 if value is not None else 404,content_type='text/css' if filename.endswith('.css') else 'application/javascript')

@app.get('/sample')
def sample():
    """[Role] Renders unmodified candidate UI with synthetic data. [Dependencies] Current Jinja frames. [Impact] No real services."""
    scene=next(s for s in payload['scenes'] if s['id']==request.args['id'])
    from flask import render_template
    template='equipment_ai_providers.html' if scene['view']=='admin' else 'equipment_ai.html'
    text=render_template(template,user={'NickName':'샘플 관리자' if scene['view']=='admin' else '샘플 사용자','Role':'admin' if scene['view']=='admin' else 'user'},assistant_csrf='synthetic-screen-csrf',csrf_token='synthetic-screen-csrf')
    bootstrap='<script>window.SCREEN_SCENE='+json.dumps(scene,ensure_ascii=False)+';</script><script>'+payload['bootstrap'].replace('</script','<\\/script')+'</script>'
    text=text.replace('<head>','<head>'+bootstrap,1)
    text=text.replace('https://cdn.tailwindcss.com','/static/js/tailwindcss.js')
    text=text.replace('</body>','<script>'+payload['inspect'].replace('</script','<\\/script')+'</script></body>')
    response=Response(text,content_type='text/html; charset=utf-8')
    response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; font-src 'none'"
    return response

@app.get('/frame')
def frame():
    """[Role] Fixes the reviewed viewport independently of Chromium CLI outer-window sizing.
    [Dependencies] Same-origin iframe with explicit validated device dimensions.
    [Impact] Scrolled content and DOM metrics agree with the actual captured scene; product CSS is untouched.
    """
    target='/sample?id='+request.args['id']
    width,height=(390,844) if request.args.get('device')=='mobile' else (1440,1000)
    text='<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body style="margin:0;overflow:hidden;background:#dfe5eb;display:flex;justify-content:center"><iframe id="review-frame" src="'+target+'" style="flex:0 0 '+str(width)+'px;width:'+str(width)+'px;height:'+str(height)+'px;border:0;background:white"></iframe><pre id="screen-result" hidden></pre><script>addEventListener("message",e=>{if(e.origin===location.origin&&e.source===document.getElementById("review-frame").contentWindow&&e.data.screenResult)document.getElementById("screen-result").textContent=e.data.screenResult;});</script></body></html>'
    return Response(text,content_type='text/html; charset=utf-8')

server=make_server('127.0.0.1',0,app,threaded=True,request_handler=Quiet)
thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
results=[]
try:
    for scene in payload['scenes']:
        for device,width,height in (('desktop',1440,1000),('mobile',390,844)):
            with tempfile.TemporaryDirectory(prefix='eq-screen-') as folder:
                target=Path(folder)/'capture.png'
                mobile=device=='mobile'
                command=['/usr/bin/chromium','--headless','--no-sandbox','--disable-gpu','--disable-dev-shm-usage','--no-proxy-server',
                    '--disable-background-networking','--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE 127.0.0.1',
                    '--user-data-dir='+str(Path(folder)/'profile'),'--force-device-scale-factor=1',
                    '--window-size='+str(500 if mobile else width)+','+str(height),'--virtual-time-budget=7000',
                    '--screenshot='+str(target),'--dump-dom','http://127.0.0.1:'+str(server.server_port)+'/frame?id='+scene['id']+'&device='+device]
                result=subprocess.run(command,capture_output=True,text=True,timeout=40)
                match=re.search(r'<pre id="screen-result"[^>]*>(.*?)</pre>',result.stdout,re.S)
                data=json.loads(html.unescape(match[1])) if match and match[1] else {'ready':False,'errors':['capture readiness marker missing'],
                    'dom_length':len(result.stdout),'dom_end':result.stdout[-2200:],'stderr_end':result.stderr[-900:]}
                results.append({'id':scene['id'],'title':scene['title'],'view':scene['view'],'theme':scene['theme'],'device':device,
                    'viewport':{'width':width,'height':height},'file':scene['id']+'-'+device+'.png','metrics':data,
                    'browser_exit':result.returncode,'png':base64.b64encode(target.read_bytes()).decode() if target.exists() else None})
finally:
    server.shutdown();thread.join(timeout=3);server.server_close()
print(json.dumps({'captures':results,'platform':sys.platform,'production_app_imported':False,'production_database_opened':False,'model_called':False}))
'''


def main():
    """[MINI-COMMENT: SCREEN.REVIEW.OUTPUT]
    [EN rev.1]
    [Role] Packs current sources and writes only explicitly requested new screenshot outputs.
    [Dependencies] SSH to eqmgmt-backup, checked PNG signatures/names and an unused output directory.
    [Impact] Existing candidate/source/report files cannot be overwritten by this capture run.
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True)
    parser.add_argument('--scene')
    args=parser.parse_args()
    project=Path(__file__).resolve().parents[2]
    overlay=project/'Staging/20261104-user-ai-assistant/overlay'
    output=Path(args.output).resolve()
    allowed=(project/'Reports/2026/11/04/010_AI_Staging_Screens').resolve()
    if not output.is_relative_to(allowed) or output.exists():
        raise ValueError('screenshot output must be a new directory within the declared review output')
    files=list((overlay/'templates').glob('*.html'))+list((overlay/'static').rglob('*.js'))+list((overlay/'static').rglob('*.css'))
    assets={p.relative_to(overlay).as_posix():p.read_text(encoding='utf-8-sig') for p in files}
    common=('templates/root_frame.html','templates/miniserver_frame.html','static/css/roadmap.css','static/css/layout.css','static/css/components.css','static/js/common.js','static/js/roadmap_preferences.js','static/js/navigation.js','static/js/menu_cards.js','static/js/catalog_requests.js','static/js/tailwindcss.js')
    for name in common:
        assets.setdefault(name,(project/name).read_text(encoding='utf-8-sig'))
        files.append(project/name)
    scenes=[{'id':ident,'title':title,'view':view,'state':state,'theme':theme,'focus':focus} for ident,title,view,state,theme,focus in (
        ('01-user-welcome','사용자 · 새 대화','user','welcome','light','top'),
        ('02-user-thinking','사용자 · 추론 진행','user','thinking','dark','top'),
        ('03-user-review','사용자 · 답변과 장비 등록 확인','user','review','light','proposal'),
        ('04-user-model-switch','사용자 · 대화 전용 모델로 변경','user','switch','dark','top'),
        ('05-user-recovery','사용자 · 연결 중단과 종료 확인 안내','user','recovery','light','top'),
        ('06-admin-new','관리자 · 새 AI 연결','admin','new','light','top'),
        ('07-admin-provider','관리자 · 기존 AI 연결','admin','provider','light','top'),
        ('08-admin-models-dark','관리자 · 공개 모델과 기능 설정','admin','models','dark','models'),
    )]
    if args.scene:
        scenes=[s for s in scenes if s['id']==args.scene]
        if not scenes:
            raise ValueError('unknown screenshot scene')
    payload={'assets':assets,'scenes':scenes,'bootstrap':Path(__file__).with_name('sample_bootstrap.js').read_text(encoding='utf-8-sig'),'inspect':Path(__file__).with_name('inspect_sample.js').read_text(encoding='utf-8-sig')}
    packed=base64.b64encode(zlib.compress(json.dumps(payload,ensure_ascii=False).encode())).decode()
    result=subprocess.run(['ssh','-o','BatchMode=yes','eqmgmt-backup','/home/nekohost/services/Mini-Server-Web-EqMgmt/.venv/bin/python','-'],
        input=REMOTE.replace('PAYLOAD',repr(packed)),text=True,encoding='utf-8',capture_output=True,timeout=600)
    if result.returncode:
        raise RuntimeError('Linux capture failed: '+result.stderr[-3000:])
    data=json.loads(result.stdout)
    if len(data['captures'])!=len(scenes)*2 or any(not c['png'] for c in data['captures']):
        for item in data['captures']:
            item.pop('png',None)
        print(json.dumps(data,ensure_ascii=False));raise RuntimeError('incomplete screenshot run')
    output.mkdir(parents=True,exist_ok=False)
    for item in data['captures']:
        name=item['file']
        if Path(name).name!=name or not name.endswith('.png'):
            raise ValueError('invalid screenshot output name')
        raw=base64.b64decode(item.pop('png'),validate=True)
        if not raw.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError('invalid screenshot bytes')
        with open(output/name,'xb') as target:
            target.write(raw)
        item['sha256']=hashlib.sha256(raw).hexdigest()
        item['image_size']=dict(zip(('width','height'),struct.unpack('>II',raw[16:24])))
        item['path']=(output/name).relative_to(project).as_posix()
    data['source_files']=[{'path':p.relative_to(project).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(set(files))]
    data['capture_sources']=[{'path':p.relative_to(project).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (Path(__file__),Path(__file__).with_name('sample_bootstrap.js'),Path(__file__).with_name('inspect_sample.js'))]
    data['method']='Current source Jinja/JS/CSS; synthetic GET responses only; local Tailwind fallback; no product design override CSS; fixed child viewports desktop 1440x1000 and mobile 390x844 (mobile native PNG 500x844 including neutral outside gutters).'
    print(json.dumps(data,ensure_ascii=False))


if __name__=='__main__':
    sys.stdout.reconfigure(encoding='utf-8')
    main()

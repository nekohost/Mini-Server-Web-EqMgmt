# 장비관리 AI 도우미 개발 후보

work_id: `IMPL-20261104-USER-AI-ASSISTANT`, 수정 `FIX-20261104-USER-AI-ASSISTANT`, 확장 `IMPLEMENT-20261104-MULTI-PROVIDER-AI`

기존 Strata 시험 화면과 별개인 `/assistant`를 구현한 Staging 후보다. `overlay/`는 프로젝트 루트에 대응한다. 아직 운영 루트 병합·Git 반영·실제 서비스 활성화는 하지 않았다.

현재 후보는 006/009 계획의 **다중 프로바이더 v3**다. 관리자 연결 관리(`/admin/ai/providers`), 자동 목록/선택과 선택형 수동 등록, 대화별 모델·추론 복원, 요청 전체의 불변 연결/프로필, 그룹별 큐, 정규화 업무 초안/출처 인계와 Gemini S01~S04를 포함한다. 설치·키 교체·허용 목록·복구 순서는 [MULTI-PROVIDER-SETUP.md](MULTI-PROVIDER-SETUP.md)를 따른다. 과거 002/004/005/008 보고서는 당시 근거로 그대로 보존하며 이번 시험 근거는 009 보고서와 별도 manifest에 기록한다.

## 구현 내용

| 영역 | 파일 | 동작 |
| --- | --- | --- |
| 독립 화면 | `templates/equipment_ai.html`, `static/css/equipment_ai.css`, `static/js/equipment_ai.js` | 본인 대화 목록/새 대화/재접속, 이전 대화·내용 불러오기, 단계별 누적 추론, 턴의 첫 답변에 한 번 자동 접힘, 사용자 재열기 유지, 중단 사유·보관 예산 안내, 확인 카드 |
| 추론·모델 선택 | `utils/ai_assistant/providers.py`, `reasoning.py`, `policy.py` | off/low/medium/high/xhigh/max 전체 표시, 모델 지원·관리자 허용 밖 disabled. Strata Qwen 사전 설정은 off/low/medium/xhigh, 기본 medium. 관리자 허용 단계·기본값과 시험 revision, 기존 별칭/접수 snapshot 보존. 설정 미지원 모델은 모델 기본값으로 구분 |
| 웹 API/인증 | `utils/ai_assistant/__init__.py` | 기존 서명 cookie/현재 계정·메뉴·토큰 재확인, CSRF/Origin, worker 인증, 공개 HTTPS의 Secure cookie, 수동 파일/CSV 경계 |
| 저장/큐 | `utils/ai_assistant/store.py` | 별도 SQLite WAL v3 가산 이전, owner 분리, offset ACK·완료 공간 예약, 물리 자원 그룹별 active 1개와 소유자 공정성, 독립 그룹 병행, 종료 불명확 잠금 보존 |
| 사용자 업무 | `utils/ai_assistant/domain.py` | 본인/공개 조회, 카탈로그 검색, 내 신청 조회, 본인 장비 등록/수정/상태, 카탈로그/노드/옵션 신청, 개인 설정·CSV |
| 별도 worker | `utils/ai_assistant/worker.py`, `transport.py` | app.py import/브라우저 cookie 없이 v3 내부 API·고정 Chat Completions SSE 사용. 제한된 dispatcher와 실제 목적지 pinning, reasoning/content 분리, 완성된 tool_calls만 서버 검증 |
| 기존 연결 | `overlay/app.py`, `overlay/static/js/session_timer.js` | 신규 모듈 설치·신규 메뉴 필터, 자동 AI 조회의 타이머/cookie 연장 제외. 기존 Strata 화면과 다른 화면의 동작 보존 |
| 감사 | `utils/ai_assistant/audit.py`, `overlay/app.py` | AI 업무 내용/오류 보존, 인증 원문 지문 보호. binary/multipart 재파싱 없이 검증 metadata, CSV 원문은 보호 파일·해시·행 수 참조로 별도 예산에 보관 |

장비 등록은 승인된 옵션 또는 승인된 모델 아래 본인의 대기 옵션에 대한 임시저장을 지원한다. 새 카테고리·제조사·라인업이 승인되지 않은 단계에서 기존 복합 등록 화면의 특수 임시 노드/대체 옵션을 자동 생성하는 동작은 복제하지 않았다. 해당 신청의 승인 후 등록하거나 기존 장비 등록 화면을 이용한다. 폐기/삭제/소유자 이전, 관리자 승인·마스터 수정·사용자 관리, 임의 SQL·코드·URL·경로/도구 추가는 제공하지 않는다.

## 인증·보안 설계

프롬프트의 안내와 서버 강제를 분리했다. cookie 서명으로 변조를 검사하고 현재 DB SessionToken/활성 상태/메뉴를 다시 조회한다. job 위임은 SessionToken 원문 대신 서버 HMAC·유효기간·DB 외부 유지보수 revision에 묶인다. 로그아웃/강제 로그아웃/복원·점검 변경 이후 이전 위임으로 작업하지 않는다. 표시용 계정 context는 인증 권한이 아니며 계정 전환 시 브라우저의 이전 대화 DOM을 지운다.

대화 소유권은 숫자 UserId에만 연결하지 않고 서버 DB의 계정 생성 시각 CreatedAt을 함께 사용한다. 복원 뒤 같은 회원 번호가 다른 계정에 재사용되더라도 이전 대화·작업·확인 카드를 열거나 이어받지 못한다. 로그인 이름 변경은 같은 계정의 대화를 유지한다. CreatedAt이 없으면 기능을 닫고 관리자의 확인을 요청하며 기존 기록을 자동 수정·삭제하지 않는다. 실제 운영 계정의 CreatedAt 계약은 통합 확인에서 별도로 검증한다.

관리자도 이 도구에서는 일반 사용자 범위로 자신의 장비만 수정하고 카탈로그는 승인 대기로 신청한다. 서버의 고정 allowlist와 닫힌 인자 schema가 업무 권한을 결정하며 모델이 만든 역할·사용자 ID·SQL·URL·일반 텍스트는 실행되지 않는다. 원시 추론은 표시 데이터이며 다음 요청의 프롬프트/명령에 재주입하지 않는다. HTML은 실행하지 않고 허용된 내부 다운로드/수동 화면 링크만 생성한다.

worker는 조회·변경 제안만 할 수 있다. 실제 변경은 본인의 CSRF/Origin 보호 확인 endpoint에서 불변 proposal의 hash/HMAC/현재 revision/선택 옵션 스냅샷을 검증한 후 실행한다. 업무 변경·기존 감사·AI 실행 영수증은 같은 장비 DB transaction에 기록한다. AI DB 업데이트 유실이나 동시 확인에도 실제 영수증을 조회하므로 중복 등록을 피한다. 확정 결과는 대화에도 서버 기록으로 남긴다.

별도 장비 schema DDL은 없다. 기존 `audit_logs`의 `AI_EXECUTE`/`ai_operations` 기록을 영수증으로 사용하고 전체 proposal ID·내용 hash·actor를 비교한다. 조회와 삽입은 `BEGIN IMMEDIATE` 안에서 수행한다. 실제 운영 데이터 크기의 영수증 조회 비용과 보존 정책은 운영 적용 전 평가해야 한다.

감사 로그의 AI 본문 전체 제외 권고는 사용자 지시에 따라 정정했다. 사용자 질문·응답·추론·제안·확정 결과·오류는 접근 로그에 남긴다. session/API/worker/CSRF/CSV 확정 token과 worker lease는 소지자가 권한을 재사용할 수 있으므로 원문 대신 같은 값끼리 연관 가능한 HMAC 지문을 남긴다. 사건을 제외하거나 업무 내용을 일괄 마스킹하지 않는다. 기존 비-AI 경로의 로깅 정책은 바꾸지 않았다. 참고: [OWASP Logging — Data to exclude](https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html#data-to-exclude).

자원 기본 제한: 사용자 질문 8,000자, 사용자 열린 턴 2개, 전체 열린 작업 20개, 분당 턴 10개/하루 200개, 사용자 대화 200개, **계정별 보관 기준선 32,000,000자 + 추가 완료 예산 기본 32,000,000자 = 총 64,000,000자**, 디스크 여유 최소 128MiB, 조회 20개 단위, 도구 호출 4개/step, 모델 호출 6회/turn, 확인 카드 8개/turn, 확인 만료 최대 15분/로그인 위임 최대 30분. idempotency 재전송은 요청 한도를 다시 소모하지 않는다. 대화는 한 번에 50개, 메시지는 60개씩 불러오며 이전 기록도 전부 페이지로 조회할 수 있다.

보관 사용량은 사용자 질문·누적 추론·현재 답변·확정 결과와 정규화 업무 초안·저장한 인계 요약의 문자열 길이를 같은 AI DB transaction에서 계산한다. 질문 접수마다 추론 100,000자 + 답변 64,000자 + 확인 결과 8×32,768자 + 초안/출처 16,384자 + 인계 요약 16,384자 = **458,912자**를 미리 예약한다. 초안 교체는 차이만, 첫 단계의 저장 요약은 한 번만 계산한다. 생성에 따라 예약을 사용량으로 전환하고 종료/취소/확인 만료 시 남은 예약을 해제한다. 부족하면 신규 접수만 제한하고 이미 생성·확정한 결과를 보존한다. 기준선은 32M, 기본 확장 포함 총 64M자다.

이 문자 예산은 디스크 바이트 한도가 아니다. 64,000,000 Unicode 문자는 UTF-8 본문만 최악 약 256MB이며 단계 스냅샷·모델 context·인덱스·WAL·접근/업무 감사·백업 용량은 추가로 든다. 물리 용량과 감사 보존 주기는 공개 적용 시 별도로 확인한다. v1→v2는 기존 대화·작업·제안·종료 불명확 잠금을 보존하는 가산 이전이고, v1에서 이미 유실된 과거 단계 추론을 새로 만들어 복구하지는 않는다.

## 운영 설정과 worker

| 환경변수 | 기본/설명 |
| --- | --- |
| `USER_AI_ENABLED` | false. 기능 활성화 시 별도 AI DB와 신규 메뉴 metadata만 생성 |
| `USER_AI_WRITE_TOOLS` | false. 조회/대화 공개 후 쓰기는 별도 활성화 |
| `USER_AI_WORKER_TOKEN` | app와 worker의 독립된 비밀, 32자 이상. 저장소·브라우저·대화·명령행 인수에 넣지 않음 |
| `USER_AI_PUBLIC_ORIGIN` | `https://nekohost.org`. 실제 브라우저 Origin과 일치시킴 |
| `USER_AI_DATABASE` | 기본 `instance/ai/assistant.sqlite3`, 로컬 보호 디렉터리. Git/공개 static/네트워크 파일시스템에 두지 않음 |
| `USER_AI_COMPLETION_RESERVE_CHARS` | app 전용 추가 보관 예산. 기본 `32000000`, 허용 범위 0~1,024,000,000자. 기준선 32,000,000자는 유지하며, 변경은 app 재기동 시 적용. worker 비밀과 함께 보호된 서버 설정으로 관리 |
| `USER_AI_INTERNAL_URL` | worker 전용 기본 `http://127.0.0.1:5000`, loopback origin만 허용 |
| `USER_AI_STRATA_URL` | 기본 `http://192.168.0.14:8080`, 서버 관리자가 고정하는 모델 API origin |
| `USER_AI_STRATA_KEY` | 기존 연결의 보호 환경 참조. worker가 생성에 사용하고 app도 자동 모델 조회 시 필요. browser/model prompt·원문 로그에는 전달하지 않음 |
| `USER_AI_PROVIDER_ENCRYPTION_KEY` | app의 독립 Fernet 키. 신규 UI API 키 암호화에 필요. Flask secret/worker token과 분리하고 DB 밖에서 보호·백업 |
| `USER_AI_PROVIDER_PREVIOUS_KEYS` | 이전 외부 Fernet 키의 JSON 배열, 기본 `[]`. 진행 요청/이전 revision 복호화용, 최대 8개 |
| `USER_AI_ALLOWED_ENDPOINTS` | app·worker에 같은 JSON 허용 목록. 기본 기존 Strata origin만 허용. 승인 host/IP:port 또는 scheme/host CIDR/port 규칙 |
| `USER_AI_DATABASE_EPOCH` | DB 밖에서 관리하는 restore 세대, 기본 `initial-v3`. AI DB 교체 시 신규 값으로 바꾸어 지연된 옛 lease를 차단 |
| `USER_AI_DISPATCHERS` | worker의 네트워크 실행자 상한, 기본 8(1~32). DB 그룹 한도 1을 늘리는 설정이 아님 |
| `USER_AI_AUDIT_ROOT` / `USER_AI_AUDIT_MAX_BYTES` | 보호 CSV 감사 원문 경로/물리 예산. 기본 instance/ai/audit-originals, 2GiB. 공간 부족은 내보내기 성공 전에 거부 |
| `USER_AI_MODEL` | `qwen3.8-flash-next-iq3_xxs`. 실제 설치 모델과 적용 전 확인 |
| `USER_AI_READ_TIMEOUT` | 1800초, 연결 5초와 분리. 네트워크 읽기 timeout이며 총 생성 시간 보장이 아님 |

기존 `SECRET_KEY`는 안정적인 강한 값이어야 한다. 없거나 짧거나 알려진 기본값이면 AI 기능은 기동을 거부한다. 기존 key 교체가 필요하면 모든 로그인 만료의 영향을 포함해 별도로 진행한다. 비밀은 권한이 제한된 서버 환경 파일로 관리하고 출력하지 않는다. 실제 공개 적용에서는 장비관리→Strata 구간의 보호도 별도로 확인한다. 브라우저 HTTPS만으로 내부 HTTP가 암호화되는 것은 아니다.

승인 후 worker 시작 명령은 서버 프로젝트의 확인된 Python으로 `python -m utils.ai_assistant.worker`이다. 현재 백업 서버에서 `.venv/bin/python` 존재와 격리 테스트 의존성을 확인했다. 아래 user systemd 단위는 검토용이며 설치/활성화하지 않았다.

다른 서비스는 기존 방식으로 Strata를 사용한다. 이 worker는 다른 요청을 취소하거나 전체 idle/우선순위/공통 큐/전용 운영을 요구하지 않는다. 사용자 취소 시 자신의 응답만 정리하고 후속 업무를 차단한다. 생성 중 connection 유실/worker crash로 자체 요청의 종료를 모르면 내부 중복 발신을 보류한다. 실제 종료를 확인한 운영자만 `python -m utils.ai_assistant.worker --acknowledge-finished <자체 job ID>`로 해당 내부 작업을 해제한다. 이 명령은 공유 Strata를 조작하지 않는다. 확인 없이 복구 해제를 하면 중복 자체 요청이 생길 수 있으므로 실행하지 않는다.

완료가 확인된 응답의 잘못된 도구 ID/인자/중복 호출, 처리 예외, 길이 종료는 `failed`로 마감하고 미확정 카드를 취소하며 큐를 해제한다. 사유 코드와 안전한 한국어 사유를 저장해 즉시·재접속 후 모두 표시한다. 연결 시간 초과/불완전 스트림처럼 upstream 종료를 모르는 경우에는 **작업 중단·종료 확인 필요**로 표시하고 자신의 재발신만 막는다. 작업이 계속 실행 중인 것처럼 표시하지 않는다. worker는 완료 보고 전달만 최대 3회 재시도하며 모델 요청은 재실행하지 않는다. 장비를 찾지 못하는 등 정상적인 업무 검증 결과는 도구 결과로 전달하고, 프로토콜 오류/예상 밖 예외와 구분한다.

## 검증과 병합 절차

로컬에서 앱/동작 테스트를 실행하지 않는다. `overlay/tests/run_assistant_fixture.py`는 Windows에서 소스만 읽고 SSH stdin으로 합성 Linux 시험을 실행하는 전달 도구다. 원격 운영 소스·설정·DB를 수정하거나 app.py를 import하지 않는다. 합성 DB와 Chromium profile은 전용 TemporaryDirectory 안에서 생성·정리된다. `--browser`는 실제 후보 DOM/CSS에 결정적 가짜 transport를 연결하여 데스크톱과 430px iframe viewport를 검사한다. 실제 Strata 생성·운영 로그인·운영 DB/부하는 이 시험과 다르다.

```text
python Staging/20261104-user-ai-assistant/overlay/tests/run_assistant_fixture.py --browser
```

Staging 검토 승인 전에는 overlay를 운영 루트에 복사하거나 서비스 설정을 변경하지 않는다. 승인 후 기준 파일 hash/기존 dirty 변경을 다시 대조하고 root 병합→정적 재검증→Git→서버 pull/commit 확인→Linux 통합·실제 모델 API 확인→단계별 활성화 순서로 진행한다. 전체 Staging을 지우지 않고 이 후보의 보존/정리 범위만 확인한다.

기존 002/004/009 시험 근거와 010 화면 검토는 당시 원본으로 보존한다. 글자색·표준 추론/관리자 설정·12px 안내문의 후속 변경은 `Reports/2026/11/04/011_AI_UI_Reasoning_Settings_Report.md`와 `011_AI_UI_Reasoning_Screens/`에 분리한다. 합성 시험은 실제 모델의 도구 선택 정확성이나 운영 전체 앱 기동·부하·취소 복구 검증을 대신하지 않는다. 기존 주석 일괄 보완(D07)은 **AI-TECHDEBT-001**에 계속 보류하고 Gemini KO 감사는 수행하지 않았다.

복귀는 신규 AI 접수/쓰기 flag를 닫고 자체 worker/요청 상태를 정리하는 방식이다. 기존 수동 장비 기능·Strata 시험 화면을 유지하고 확정된 업무·감사·AI 대화/영수증을 삭제하지 않는다. 업무 DB와 별도 AI DB의 일관된 백업/보존·실제 모델 취소/복구·운영 부하/경로는 공개 적용 전에 검증해야 한다.

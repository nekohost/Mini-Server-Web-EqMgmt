/* [MINI-COMMENT: SCREEN.REFINEMENT.OBSERVE]
 * [EN rev.1]
 * [Role] Waits for real candidate initialization and records visible geometry/theme/controls.
 * [Dependencies] Synthetic scene, current candidate DOM and normal user-equivalent scroll/list selection.
 * [Impact] Does not replace product nodes/styles or turn a hidden/broken state into a passing screen.
 */
document.addEventListener('DOMContentLoaded', async () => {
    const scene = window.SCREEN_SCENE;
    const report = document.createElement('pre'); report.id = 'screen-result'; report.hidden = true; document.body.append(report);
    /** [Role] Waits for a real render condition. [Dependencies] Candidate DOM. [Impact] Timeouts are reported, not hidden. */
    const wait = async test => { for (let i=0;i<600;i++) { if (test()) return; await new Promise(resolve => setTimeout(resolve,10)); } throw Error('candidate screen did not initialize'); };
    /** [Role] Measures an element without changing it. [Dependencies] Computed style/rect. [Impact] Retains evidence of clipping and small text. */
    function measure(selector) {
        const element = document.querySelector(selector);
        if (!element) return null;
        const rect = element.getBoundingClientRect(), style = getComputedStyle(element);
        let parent = element, background = 'rgba(0, 0, 0, 0)';
        while (parent) { const value = getComputedStyle(parent).backgroundColor; if (value !== 'rgba(0, 0, 0, 0)' && value !== 'transparent') { background=value; break; } parent=parent.parentElement; }
        return { selector, text: element.textContent.trim().slice(0,180), x:rect.x,y:rect.y,width:rect.width,height:rect.height,font_size:style.fontSize,color:style.color,background,
            disabled:Boolean(element.disabled),hidden:Boolean(element.hidden)||style.display==='none',scroll_height:element.scrollHeight,client_height:element.clientHeight,
            in_viewport:rect.width>0&&rect.height>0&&rect.bottom>0&&rect.top<innerHeight&&rect.right>0&&rect.left<innerWidth };
    }
    let data;
    try {
        if (scene.view==='admin') {
            await wait(()=>document.querySelector('#provider-list button'));
            if (scene.state!=='new') document.querySelector('#provider-list button').click();
            if (scene.focus==='models' || scene.focus==='reasoning') {
                await wait(()=>document.querySelector('.provider-model-card'));
                const target=scene.focus==='reasoning' ? document.querySelector('.provider-reasoning') : document.getElementById('provider-models-panel'), nav=document.querySelector('nav[aria-label="전역 네비게이션"]');
                window.scrollTo(0,target.getBoundingClientRect().top+scrollY-(nav?nav.getBoundingClientRect().height:0)-14);
            }
        } else {
            await wait(()=>document.querySelector('#ai-model option'));
            if (scene.state!=='welcome') await wait(()=>document.querySelector('.ai-message')&&document.getElementById('equipment-ai').getAttribute('aria-busy')==='false');
            if (scene.state==='thinking') await wait(()=>document.querySelector('.ai-thought[open]'));
            if (scene.focus==='proposal') {
                const pane=document.getElementById('ai-scroll');
                await wait(()=>document.querySelector('.ai-proposal'));
                pane.scrollTop=pane.scrollHeight;
            }
        }
        await new Promise(resolve=>setTimeout(resolve,500));
        data={ready:true,viewport:{width:innerWidth,height:innerHeight},theme:document.documentElement.className,document_width:document.documentElement.scrollWidth,document_height:document.documentElement.scrollHeight,
            body_background:getComputedStyle(document.body).backgroundColor,errors:window.SCREEN_ERRORS,
            reasoning_options:[...document.querySelectorAll('#ai-level option')].map(option=>({value:option.value,label:option.textContent,disabled:option.disabled,selected:option.selected})),
            admin_reasoning:[...document.querySelectorAll('.provider-model-card:first-child [data-reasoning-level]')].map(input=>({value:input.dataset.reasoningLevel,disabled:input.disabled,checked:input.checked})),
            elements:['#equipment-ai','#ai-model','#ai-model-status','#ai-level','#ai-level-help','#ai-send','#ai-progress-text','#ai-cancel','.ai-thought','.ai-answer','.ai-source','.ai-confirm','.ai-footnote','.ai-file-tools','#ai-scroll',
                '#ai-providers-admin','#provider-heading','#provider-form label','#provider-save','#provider-status','.provider-model-card h3','.provider-model-card p','.provider-model-card label','.provider-model-card button','.provider-reasoning','.provider-reasoning legend','#provider-form input[name=name]','.provider-model-card select'].map(measure).filter(Boolean)};
    } catch(error) { data={ready:false,errors:[error.message,...window.SCREEN_ERRORS]}; }
    report.textContent=JSON.stringify(data);
    if(window.parent!==window)window.parent.postMessage({screenResult:report.textContent},location.origin);
    window.dispatchEvent(new Event('pagehide'));
});


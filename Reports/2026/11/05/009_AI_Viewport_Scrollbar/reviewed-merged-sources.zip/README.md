# AI CSV 팝업·화면 높이·스크롤바 통합 후보

상태: **기존 CSV 팝업에 화면 높이/스크롤바 개선 병합 및 정적/격리 스크린샷 검증 완료. 운영 미반영**.

- [계획](../../Plans/2026/11/05/007_AI_Assistant_CSV_Popup_Plan.md)
- [Task](../../Tasks/2026/11/05/007_AI_Assistant_CSV_Popup_Task.md)
- [검증 보고서](../../Reports/2026/11/05/007_AI_Assistant_CSV_Popup_Report.md)
- [검증·소스 해시](../../Reports/2026/11/05/007_AI_Assistant_CSV_Popup/validation.json)
- [009 통합 계획](../../Plans/2026/11/05/009_AI_Viewport_Scrollbar_Plan.md)
- [009 Task](../../Tasks/2026/11/05/009_AI_Viewport_Scrollbar_Task.md)
- [009 검증 보고서](../../Reports/2026/11/05/009_AI_Viewport_Scrollbar_Report.md)
- [009 검증·소스 해시](../../Reports/2026/11/05/009_AI_Viewport_Scrollbar/validation.json)
- [007 보존 원본](../../Reports/2026/11/05/007_AI_Assistant_CSV_Popup/reviewed-csv-popup-sources.zip): 이전 검증의 원문10개/해시를 보존한다.
- 기준 root HEAD: cb1d72c. baseline.json의 root11개 SHA를 보존한다.

운영 대상 후보는 overlay의 template/JS/CSS/policy4개다. 하단 업무 안내·파일 details는 없고 사용자가 요청한 대화 링크로 native dialog를 연다. CSV 가져오기·첨부의 기존 API 및 CSV 내보내기 확인/영수증과 현재 계정 권한을 유지한다. 별도의 JS 라이브러리·DB migration·새 모델 도구/외부 주소는 추가하지 않았다.

실측 viewport/top/컨테이너 여백으로 높이를 맞추고, PC620px/모바일550px와 고정 제어 영역+대화120px의 최소 조건을 유지한다. 충분한 높이에서 문서 세로 스크롤을 없애고 부족하면 문서 스크롤을 유지한다. AI 내부 native scrollbar에 라이트/다크 색상을 적용한다. web_search는 제외되어 있다.

검증 보조6개는 sparse overlay 지원 runner, 기존 footer 기대값을 새 흐름에 맞춘 browser fixture2개, CSV 팝업 fixture, 실시간 프레임 캡처를 선택 지원하는 공통 UI fixture와 viewport/scrollbar fixture다. runner는 변경 없는 app/테스트/폐기 안내를 root에서 합성해 메모리로 SSH 전송한다. 실제 앱 import/테스트는 Linux 격리 환경에서만 수행한다. Windows의 이 CLI는 소스 포장·결과/PNG 아티팩트 저장만 한다.

```powershell
$env:PYTHONUTF8='1'
& 'C:/Users/nkhst/AppData/Local/hermes/tools/python-3.14.9+20261021-win32-x64/python.exe' Staging/20261105-ai-csv-popup/overlay/tests/run_assistant_fixture.py --browser-only --summary-only --tmpfs-fixtures --artifact-dir Reports/2026/11/05/009_AI_Viewport_Scrollbar/screenshots-review-new
```

artifact-dir는 기존 결과를 덮어쓰지 않도록 매번 새 이름을 쓴다. `--browser-only --browser-target popup-short`는320×620/390×844의 추가 팝업 검사를 실행하며 `--browser-target viewport`는 높이/내부 스크롤8개 화면만 실행한다. 이 높이 검사는 가상 시간에서 rAF 반영 전의 값을 읽지 않도록 격리 Chromium의 private CDP pipe로 실제 프레임을 기다린다. `--browser-only`의 unittest0은 브라우저 전용 실행이며 전체 backend178 결과와 구분한다. full browser 결과는 PNG 옆 results.json에 남는다.

현재 통합43개 화면/3215개 검사(높이8개/284개 포함)와 짧은 모바일4개/112개, 합계47개 화면/3327개가 통과했다. backend178개는 Python 업무 소스가 바뀌지 않은007 당시 증거를 승계하며 이번 프론트엔드 작업에서 다시 실행한 수로 집계하지 않는다. 프로그램 focus/cancel/scroll 검증이며 실기기 키보드·핀치 확대/실모델의 안내 준수·운영 CSV 전송을 검증한 결과는 아니다. 별도 승인 전 root 병합/배포는 수행하지 않는다.

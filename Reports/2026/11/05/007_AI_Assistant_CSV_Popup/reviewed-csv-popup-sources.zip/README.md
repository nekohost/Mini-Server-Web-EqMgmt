# AI 하단 정리·요청형 CSV 팝업 후보

상태: **Staging 구현·정적/격리 스크린샷 검증 완료, 운영 미반영**.

- [계획](../../Plans/2026/11/05/007_AI_Assistant_CSV_Popup_Plan.md)
- [Task](../../Tasks/2026/11/05/007_AI_Assistant_CSV_Popup_Task.md)
- [검증 보고서](../../Reports/2026/11/05/007_AI_Assistant_CSV_Popup_Report.md)
- [검증·소스 해시](../../Reports/2026/11/05/007_AI_Assistant_CSV_Popup/validation.json)
- 기준 root HEAD: cb1d72c. baseline.json의 root11개 SHA를 보존한다.

운영 대상 후보는 overlay의 template/JS/CSS/policy4개다. 하단 업무 안내·파일 details는 없고 사용자가 요청한 대화 링크로 native dialog를 연다. CSV 가져오기·첨부의 기존 API 및 CSV 내보내기 확인/영수증과 현재 계정 권한을 유지한다. 별도의 JS 라이브러리·DB migration·새 모델 도구/외부 주소는 추가하지 않았다.

검증 보조4개는 sparse overlay 지원 runner, 기존 footer 기대값을 새 흐름에 맞춘 browser fixture2개, 신규 CSV 팝업 fixture다. runner는 변경 없는 app/테스트/폐기 안내를 root에서 합성해 메모리로 SSH 전송한다. 실제 앱 import/테스트는 Linux 격리 환경에서만 수행한다. Windows의 이 CLI는 소스 포장·결과/PNG 아티팩트 저장만 한다.

```powershell
$env:PYTHONUTF8='1'
& 'C:/Users/nkhst/AppData/Local/hermes/tools/python-3.14.9+20261021-win32-x64/python.exe' Staging/20261105-ai-csv-popup/overlay/tests/run_assistant_fixture.py --browser --summary-only --tmpfs-fixtures --artifact-dir Reports/2026/11/05/007_AI_Assistant_CSV_Popup/screenshots-review-new
```

artifact-dir는 기존 결과를 덮어쓰지 않도록 매번 새 이름을 쓴다. `--browser-only --browser-target popup-short`는320×620/390×844의 추가 팝업 검사를 실행한다. `--browser-only`의 unittest0은 브라우저 전용 실행이며 전체 backend178 결과와 구분한다. full browser 결과는 PNG 옆 results.json에 남는다.

기본 화면35개/2931개 검사, 추가 짧은 모바일4개/112개 검사와 backend178개가 통과했다. 프로그램 focus/cancel 이벤트 검증이며 실기기 키보드/실모델의 안내 준수·운영 CSV 전송을 검증한 결과는 아니다. 이번 후보를 제거하면 기존 운영 코드로 계속 사용하며, 별도 승인 전 root 병합/배포는 수행하지 않는다.

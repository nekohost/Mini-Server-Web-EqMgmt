# AI 화면 개선1~10 검토 후보

work_id: `STAGING-20261105-AI-POLISH`. 사용자 승인 범위는 Staging 구현·정적 및 합성 Linux browser 검증까지다. 운영 root/서버/DB에는 아직 반영하지 않는다.

기준은 현재 root 파일이며 대응 경로로 병합하는 overlay다. Windows에서 이 후보의 Flask 앱을 직접 실행하지 않는다. Linux 검증은 기존 tests/run_assistant_fixture.py의 임시 합성 프로젝트 방식을 사용한다. 생성 결과는 Reports/2026/11/05/016_AI_Polish에 보존한다.

담당 소유권: 화면/포털 agent(template/CSS/menu_cards), 생명주기 agent(main equipment_ai.js의 rename/bulk 및 rename backend), 출력 agent(독립 ai_stream_presenter.js), 부모(연결/큐 상태 backend와 통합·검증). 기본 파일 복사 후 각 담당 파일만 구조화 편집한다.

## 재현

프로젝트 root에서 기존 SSH alias `eqmgmt-backup`의 인증된 Linux 합성 fixture를 사용한다. 다음 Python runner는 Windows에서 앱을 import하지 않고 후보 문자열만 전달한다. 결과 디렉터리는 존재하지 않는 새 경로로 지정한다.

```powershell
$env:PYTHONUTF8='1'
& 'C:/Users/nkhst/AppData/Local/hermes/tools/python-3.14.9+20261021-win32-x64/python.exe' Staging/20261105-ai-polish/tests/run_assistant_fixture.py --tmpfs-fixtures --summary-only
node --test Staging/20261105-ai-polish/tests/test_ai_stream_presenter.js
& 'C:/Users/nkhst/AppData/Local/hermes/tools/python-3.14.9+20261021-win32-x64/python.exe' Staging/20261105-ai-polish/tests/run_assistant_fixture.py --browser-only --browser-target polish --artifact-dir Reports/2026/11/05/016_AI_Polish/recheck-polish --summary-only
```

`--browser-target portal/ui/disclosure/viewport/popup-short`로 별도 회귀를 선택하고 `--browser-width 390 --browser-width 1440`, `--browser-theme dark` 등으로 대상 범위를 제한할 수 있다. 스트리밍 성능 측정은 다른 Chromium 시험과 겹치지 않게 실행한다. 모델 생성 속도나 실제 운영 장비 자료를 시험하는 명령이 아니다.

# AI CSV 팝업·화면 맞춤·모델 선택 접기 통합 후보

상태: **009 통합 후보에010 모델 선택 접이식 병합 및 정적/격리 스크린샷 검증 완료. 운영 미반영**.

- [계획](../../Plans/2026/11/05/007_AI_Assistant_CSV_Popup_Plan.md)
- [Task](../../Tasks/2026/11/05/007_AI_Assistant_CSV_Popup_Task.md)
- [검증 보고서](../../Reports/2026/11/05/007_AI_Assistant_CSV_Popup_Report.md)
- [검증·소스 해시](../../Reports/2026/11/05/007_AI_Assistant_CSV_Popup/validation.json)
- [009 통합 계획](../../Plans/2026/11/05/009_AI_Viewport_Scrollbar_Plan.md)
- [009 Task](../../Tasks/2026/11/05/009_AI_Viewport_Scrollbar_Task.md)
- [009 검증 보고서](../../Reports/2026/11/05/009_AI_Viewport_Scrollbar_Report.md)
- [009 검증·소스 해시](../../Reports/2026/11/05/009_AI_Viewport_Scrollbar/validation.json)
- [010 모델 선택 접기 계획](../../Plans/2026/11/05/010_AI_Model_Disclosure_Plan.md)
- [010 Task](../../Tasks/2026/11/05/010_AI_Model_Disclosure_Task.md)
- [010 검증 보고서](../../Reports/2026/11/05/010_AI_Model_Disclosure_Report.md)
- [010 검증·소스 해시](../../Reports/2026/11/05/010_AI_Model_Disclosure/validation.json)
- [009 보존 원본](../../Reports/2026/11/05/009_AI_Viewport_Scrollbar/reviewed-merged-sources.zip)
- [007 보존 원본](../../Reports/2026/11/05/007_AI_Assistant_CSV_Popup/reviewed-csv-popup-sources.zip): 이전 검증의 원문10개/해시를 보존한다.
- 기준 root HEAD: cb1d72c. baseline.json의 root11개 SHA를 보존한다.

운영 대상 후보는 overlay의 template/JS/CSS/policy4개다. 하단 업무 안내·파일 details는 없고 사용자가 요청한 대화 링크로 native dialog를 연다. CSV 가져오기·첨부의 기존 API 및 CSV 내보내기 확인/영수증과 현재 계정 권한을 유지한다. 별도의 JS 라이브러리·DB migration·새 모델 도구/외부 주소는 추가하지 않았다.

실측 viewport/top/컨테이너 여백으로 높이를 맞추고, PC620px/모바일550px와 고정 제어 영역+대화120px의 최소 조건을 유지한다. 충분한 높이에서 문서 세로 스크롤을 없애고 부족하면 문서 스크롤을 유지한다. AI 내부 native scrollbar에 라이트/다크 색상을 적용한다. web_search는 제외되어 있다.

모델 select/목록 새로고침은 추론 아래·지원 안내 위의 `AI 모델 선택` native details로 이동했다. 첫 표시에서는 접혀 있고 사용자가 펼친 상태는 모델 변경/새로고침 때문에 강제로 바뀌지 않는다. 모델 오류·상태는 접힘 밖에 남는다. 업무 client JS/policy/API는009와 동일하다.

검증 보조7개는 sparse overlay 지원 runner, 대화/lifecycle browser fixture2개, CSV 팝업 fixture, 실시간 프레임 캡처를 선택 지원하는 공통 UI fixture, viewport/scrollbar fixture와 모델 접이식 fixture다. 모델 제어 크기/포커스의 기존 검사는 펼친 상태를 명시하고 기본 접힘은 별도로 검사한다. runner는 변경 없는 app/테스트/폐기 안내를 root에서 합성해 메모리로 SSH 전송한다. 실제 앱 import/테스트는 Linux 격리 환경에서만 수행한다. Windows의 이 CLI는 소스 포장·결과/PNG 아티팩트 저장만 한다.

```powershell
$env:PYTHONUTF8='1'
& 'C:/Users/nkhst/AppData/Local/hermes/tools/python-3.14.9+20261021-win32-x64/python.exe' Staging/20261105-ai-csv-popup/overlay/tests/run_assistant_fixture.py --browser-only --summary-only --tmpfs-fixtures --artifact-dir Reports/2026/11/05/010_AI_Model_Disclosure/screenshots-review-new
```

artifact-dir는 기존 결과를 덮어쓰지 않도록 매번 새 이름을 쓴다. `--browser-only --browser-target popup-short`는320×620/390×844의 추가 팝업 검사를 실행하며 `--browser-target viewport`는 높이/내부 스크롤8개, `--browser-target disclosure`는 모델 접기/펼치기8개 화면만 실행한다. 이 높이/접이식 검사는 가상 시간에서 rAF 반영 전의 값을 읽지 않도록 격리 Chromium의 private CDP pipe로 실제 프레임을 기다린다. `--browser-only`의 unittest0은 브라우저 전용 실행이며 전체 backend178 결과와 구분한다. full browser 결과는 PNG 옆 results.json에 남는다.

현재 통합51개 화면/3431개 검사와 짧은 모바일4개/112개, 합계55개 화면/3543개가 통과했다. 모델 접이식8개/168개와 viewport8개/284개는 통합51개에 포함한다. 009의47개 화면/3327개 증거도 이전 원문과 함께 보존되어 있다. backend178개는 Python 업무 소스가 바뀌지 않은007 당시 증거를 승계하며 이번 프론트엔드 작업에서 다시 실행한 수로 집계하지 않는다. 모바일430px은 종전보다 대화 높이가26.406px 늘었고, PC1440px은 요청한 세로 배치의 summary 행으로25.594px 줄었다. 새 UI 자체의 펼침 대비 접힘은 모바일52px/PC44px의 제어 행을 덜 차지한다. 프로그램 focus/cancel/scroll 검증이며 실기기 키보드·핀치 확대/실모델의 안내 준수·운영 CSV 전송을 검증한 결과는 아니다. 별도 승인 전 root 병합/배포는 수행하지 않는다.

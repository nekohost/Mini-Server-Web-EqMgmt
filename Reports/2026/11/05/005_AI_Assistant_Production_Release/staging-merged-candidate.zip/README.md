# AI 도우미 1~7번 및 공간 절약 배치 Staging 후보

승인 Plan: `Plans/2026/11/05/001_AI_Assistant_UX_and_Strata_Retirement_Plan.md`.
작업: `STAGING-20261105-AI-UX-TRASH`.

후속 승인 Plan: `Plans/2026/11/05/003_AI_Assistant_Compact_Layout_Plan.md`.
가산 병합 작업: `STAGING-20261105-AI-COMPACT-LAYOUT`.
기존 1~7번 산출물에 제목/모델 컨트롤 배치를 병합한다. 표·휴지통·관리자 연결 관리·v4 저장소/worker·옛 UI 정리 후보를 유지한다. 변경 전 Report 002는 고정 근거로 보존하며 추가 변경의 실행 결과는 Report 004를 기준으로 한다.

`overlay/`는 프로젝트 root에 대응하는 변경 후보다. Windows에서 앱을 기동하지 않는다. 기존 root 코드·운영 DB·서비스는 이 작업에서 수정하지 않는다. 제거할 옛 화면 자산과 Nginx 전환은 후보 목록/설치 절차로 별도 기록한다. 적용 전 사용자 승인 범위와 v4 호환성/실행 점유·백업·timer 순서를 확인한다.

편집 소유권:

- chat_ui: `static/js/equipment_ai.js`, `static/css/equipment_ai.css`, `templates/equipment_ai.html`, 사용자 UI 회귀 fixture.
- admin_retirement: `app.py`, `utils/strata_integration.py`, 관리자 JS/CSS/template, 옛 Strata 설치/검사/문서·제거 목록, 해당 회귀.
- lifecycle_store: `utils/ai_assistant/store.py`, `providers.py`, `worker.py`, 신규 lifecycle 모듈/정리 CLI/systemd unit/저장소 회귀.
- parent: `utils/ai_assistant/__init__.py`, `domain.py`, `policy.py`, `context.py`, 공통 회귀/fixture·통합 검증/설치 문서. 공유 파일은 먼저 부모에게 협의한다.

공간 절약 추가 작업의 편집 소유권은 template/CSS=`compact_layout`, 사용자 JS=`compact_state`, 사용자 브라우저 회귀=`compact_checks`, 측정·기존 회귀 통합·문서/검증=`parent`로 나눴다. 모델 select 최대 136 CSS px는 변경 전 Qwen/medium 추론 select를 측정한 값이고, 새 추론 select는 짧은 고정 옵션의 고유 너비를 따른다. 모바일 제목과 목록 서랍은 같은 760px 기준을 사용하고 넓은 화면의 내부 헤더는 레이아웃을 차지하지 않는다.

# AI 대화 수명주기 저장소 후보

작업 범위는 승인된 `Plans/2026/11/05/001_AI_Assistant_UX_and_Strata_Retirement_Plan.md` 7번과 부모의 `Tasks/2026/11/05/002_AI_Assistant_Seven_Improvements_Staging_Task.md`다. 모든 산출물은 이 Staging 아래에 있다. 운영 root 소스·실제 DB·서비스·모델을 수정하거나 호출하지 않았다. 추가 재위임은 하지 않았다. 도구에 Fast 독립 설정/검증 항목이 없으므로 Fast 사용을 보장하지 않는다.

## 사전 확인과 편집 경계

- 하위 작업자가 `AGENTS.md`를 읽고 recorder ensure → profile → manifest/validate/catalog → context와 전체 선택 노드를 직접 확인했다. profile은 legacy / `runtime-thread-id-conflict`, 실제 모델 미확인으로 표시되었으며 숨기지 않았다. governance validate는 44 노드, 오류/경고 0이었다.
- 승인 Plan 전체와 002 Task/Report, 구현 전 Validation 1~8의 기록을 읽었다. 부모의 `__init__.py`/`domain.py`/`policy.py`/`context.py`, UI 및 관리자 후보는 직접 편집하지 않았다.
- 원본 `store.py`, `providers.py`, `worker.py`를 메모리에서 읽고 `apply_patch` Add File로 후보를 생성했다. 이후 수정도 구조화된 `apply_patch`만 사용했다. 현재 root 세 파일의 전체 텍스트는 최초 읽기와 동일함을 직접 대조했다.
- 변경된 기존 추적 주석의 EN revision을 증가시켰다. KO 본문/revision 및 comment-sync 기준선은 대신 동기화하지 않았다.

## 구현 파일과 계약

| 후보 | 역할 |
| --- | --- |
| `overlay/utils/ai_assistant/store.py` | v4 기동, active/trash 읽기·목록·메시지, 작업 경계, 단일 그룹 claim, 문자 예산 |
| `overlay/utils/ai_assistant/lifecycle.py` | 추가 migration, 삭제 조작 원장, 휴지통/복구/영구삭제/만료, 본문과 독립된 실행 원장, 복원 시 삭제 이력 대조 |
| `overlay/utils/ai_assistant/providers.py` | v4를 v3으로 내리지 않는 migration, 독립 실행 원장과 일치하는 legacy quarantine/그룹 변경 검사 |
| `overlay/utils/ai_assistant/worker.py` | 실제 호출 직전 서버 진입 확인, 취소 후 자신의 stream drain·본문 폐기, 고정 finish 보고의 404/409 경합 재전달 |
| `overlay/tools/ai_retention_cleanup.py` | Linux 단일 정리 명령, v4 선검사, 만료 정리 및 오프라인 삭제 이력 export/apply |
| `overlay/systemd/equipment-ai-retention.service`, `.timer` | 독립 user oneshot, 5분 calendar와 startup catch-up, 실제 설치/활성화하지 않은 후보 |
| `overlay/tests/test_ai_conversation_lifecycle.py` | Linux 한정 synthetic Store 및 실제 CLI 메모리 fixture 회귀 |

부모와 합의한 Store 호출은 다음과 같다.

- `conversation(owner,cid,db,account_key,view='active')`: 기본 active 전용. trash는 같은 owner/account이며 `now < purge_after`일 때만 읽는다.
- `conversations(owner,account_key,cursor=None,view='active')`, `snapshot(owner,cid,account_key,before=None,view='active')`: 상태가 cursor에 포함되며 다른 view에 재사용할 수 없다. 삭제 메타·revision·read_only·server_time을 반환한다. 목록의 순수 probe를 제외하고, mixed 대화는 보존하되 일반 메시지/문맥에 probe 행을 섞지 않는다. 관리자 probe job 조회는 유지한다.
- `lifecycle(owner,cid,account_key,action,revision,operation_id)`: action은 trash/restore/purge. 짧은 `BEGIN IMMEDIATE`에서 owner/account·현재 상태·revision·서버 UTC를 재검사한다. operation_id는 기존 `opaque()` 계약의 소문자 32hex이고 malformed는 기존 정책대로 404다. 새 operation은 owner/account별 60회/분으로 제한하며 기존 멱등 재전송을 먼저 처리한다.
- `with execution_gate(owner,cid,account_key) as ai_db`: 부모 confirm이 proposal 재조회 → 짧은 업무 DB 확정 → AI 영수증 기록을 같은 AI writer 안에서 수행한다. 이 게이트에서 모델/네트워크 대기나 중첩 AI writer를 사용하지 않는다.
- `guard_event(jid,lease)`, `guard_finish(jid,lease,outcome)`: 정상 active 작업이면 None을 반환한다. trash/purge/cancel 경계에서는 최소 제어 원장만 갱신하고 본문/추론/도구 인자를 버린다. 부모 API는 early 검사와 jobs 삭제 경합 fallback을 연결했다.
- `acknowledge_finished(jid)`: 기존 worker/operator 전용 명시적 종료 확인이 content-free guard도 해제한다. 브라우저/모델의 승인 경로로 노출하지 않는다.

정상+휴지통을 합한 200개 대화와 문자 예산을 유지한다. 휴지통 이동으로 used_chars가 줄지 않으며 queued 예약은 취소 정책에 따라 해제된다. 대화 purge 뒤에도 detached active guard가 기존 전체 20개/owner 2개 접수 제한에 포함된다.

## 스키마·경합·삭제 범위

conversations에 `is_deleted`, `deleted_at`, `purge_after`, `lifecycle_revision`을 추가하며 기존 행은 모두 0/NULL/NULL/0이다. 시간은 서버 UTC epoch이고 30일은 정확히 2,592,000초다. 같은 휴지통 요청이나 이미 이동한 상태의 새 조작은 기산일을 늘리지 않는다. 복구 뒤 새 이동만 새로운 30일을 만든다. 만료 정각부터 조회/복구를 거절한다.

`ai_execution_guards`에는 job/group·owner/account identity·worker/lease hash/epoch·상태/취소/시각만 둔다. 대화 FK, 제목, 본문, 추론, 도구 인자, API 키를 넣지 않는다. 유일한 그룹 점유 인덱스 `one_group_request`는 jobs에서 이 원장으로 이전한다. claim만 실행 점유를 얻으며 running/draining/recovery_required 상태는 실제 종료 확인까지 유지한다. v4 기동은 정확한 unique index SQL/predicate, 모든 사용 컬럼, 라이프사이클 인덱스, 상태와 active job/guard 정합을 검사한다. partial v4나 tombstone과 대화가 함께 살아 있는 불완전 복원을 자동 수리하지 않는다.

휴지통 이동은 queued 요청과 pending proposal을 취소하고 자기 running만 draining으로 바꾼다. 복구는 취소 상태를 초기화하지 않는다. append/reconcile/step 저장/proposal/draft/handoff/claim/선택·접수 경계는 writer 안에서 상태를 재검사한다. 삭제·복구 경합 뒤 늦은 출력도 저장하거나 대화를 재생성하지 않는다. 알려지지 않은 종료는 오래됐다는 이유로 해제하지 않는다.

영구삭제는 proposals → message_steps → draft → selection_events → messages → jobs → conversations 순으로 동일 transaction에서 처리한다. 비FK `messages.job`의 다른 conversation 오염을 발견하면 전체 rollback한다. messages 본문+추론, handoff_chars, draft.data 길이를 실제로 합산하여 storage_accounts에서 한 번 차감한다. 원장 부족/DB 예외 시 삭제와 조작 영수증까지 rollback한다. jobs 예약 행은 삭제되며 최소 active guard는 남는다.

장비·확정된 업무·업무 감사·AI_EXECUTE 영수증·보호 CSV 감사 원본/ai_audit_artifacts·프로바이더·모델·키·그룹·revocations·계정 전체 storage_accounts는 삭제 범위에 넣지 않는다. 조작 원장과 tombstone은 내용 없는 identity/state/count 기록만 보관한다. 물리 매체·별도 감사·기존 백업 전체를 즉시 secure erase했다는 의미가 아니다.

## 정리 후보의 설치·운영 전제

이 후보는 설치하거나 활성화하지 않았다. 검증된 v4 코드/Store/API/worker/실행 원장의 묶음 반영과 일관 백업 후에만 별도 운영 승인 절차에서 설치한다. 기존 v3 코드는 version 4를 이해하지 못하므로 그대로 롤백 실행하지 않는다. provider.migrate는 version 4를 3으로 내리지 않는다. 복귀할 때는 timer를 중지하고 v4/휴지통을 이해하는 호환 코드를 사용한다.

정리 CLI는 **기존 DB의 readonly ai_meta가 정확히 [4]인지 먼저 확인**하고, 그 후에만 Store를 연다. 따라서 timer가 v3 migration이나 기능 활성화를 대신하지 않는다. DB 경로 옆 0600 no-follow lock file에 Linux `flock(LOCK_EX|LOCK_NB)`를 잡아 중복 정리를 차단한다. 기본 25행×4 batch이고 한 batch는 단일 짧은 writer다. 만료 인덱스로 읽고 삭제 직전 state/revision/deadline을 다시 검사한다. 현재 batch 실패는 rollback하며 유형/건수/다음 실행 재시도를 기록한다.

service의 환경 파일은 `%h/.config/eqmgmt/assistant-worker.env`다. **기존 설치의 이 파일에 USER_AI_DATABASE가 없을 수 있으므로**, 설치 전에 앱과 동일한 절대 AI DB 경로와 `USER_AI_DATABASE_EPOCH`를 명시해야 한다. 값이 없으면 CLI는 실패한다. 기존 앱의 실제 epoch를 재사용하며 정리를 위해 임의로 epoch를 바꾸지 않는다. 기본 unit의 ReadWritePaths는 `%h/services/Mini-Server-Web-EqMgmt/instance/ai`이므로 다른 DB 위치라면 검토한 정확한 directory drop-in이 필요하다.

timer는 OnStartupSec=15s와 5분 calendar/Persistent=true다. 만료 즉시 접근/복구는 막고, 실제 내용 정리는 정상 실행 시 한 주기 정도 지연될 수 있다. 큰 backlog는 bounded batch 여러 실행으로 따라잡는다. 모델 호출·사용자 로그인·정상 모델 생성 총시간 timeout과 무관하다.

## 과거 AI 백업 복원 절차

삭제 이력을 포함하지 않은 과거 AI DB를 혼자 교체하여 바로 기동하면 영구삭제한 대화가 다시 나타날 수 있다. 다음은 **실행하지 않은 운영 절차**이며 실제 교체는 별도 승인이 필요하다.

1. 앱/worker/timer를 유지보수 상태로 멈추고, 현재 최소 실행 원장의 모든 자체 upstream 요청 종료를 확인한다. 불명확한 요청의 점유를 백업 교체로 지우지 않는다. 종료 확인 없이 오래된 DB로 바꾸는 복원은 허용하지 않는다.
2. 현재 최신 v4 DB에서 `tools/ai_retention_cleanup.py --export-deletions`의 JSON을 권한 제한된 별도 파일/백업에 보존한다. 본문·제목·키가 없고, 기존 tombstones와 아직 GC가 수거하지 않은 만료 trash의 삭제 결정도 포함한다. 최대 10,000행이며 초과 시 조용히 생략하지 않고 실패한다.
3. 일관 백업 사본을 오프라인 복원하고, v3 사본이면 검토한 v4 호환 migration을 명시적으로 수행한다. timer는 이 이전을 수행하지 않는다. 최신 삭제 이력 파일을 보존한 채 `--reconcile-deletions <보호된 JSON>`을 복원 v4 DB에 적용한다.
4. importer는 최대 8MiB·10,000행, 닫힌 필드, 32hex ID, owner/account, 유한 시각/revision, CID/operation 충돌을 검사한다. 전체 identity preflight 후 25행 단위 transaction으로 실제 복원 본문을 지우고 문자 원장을 차감한다. 재실행은 멱등이며 실패하면 서비스는 중지 상태를 유지하고 원인을 확인한다. 더 최신 revision/다른 owner/account와 충돌하면 fail-closed한다.
5. 삭제 이력·FK·문자 원장·active guard를 검증하고, 기존 복원 정책에 따라 epoch를 갱신한 뒤 v4 호환 서비스와 timer를 재개한다. 이전 lease는 epoch 경계를 넘어 재사용하지 않는다. 삭제 이력 자체를 이미 잃은 과거 백업만으로 전체 삭제 결정을 복원했다고 주장하지 않는다.

## 검증 기록

- Python 6개 후보의 AST parse를 설치된 Python 3.14.9로 통과했다. Windows에서는 앱·행동 회귀를 실행하지 않았다. 처음 `python` 명령은 WindowsApps alias뿐이라 실행되지 않았고, 부모가 확인한 설치된 interpreter 경로로 정적 검사만 수행했다.
- 부모의 Linux 격리 focus에서 당시 Store 회귀 23개와 API 경합 1개 중 23개가 통과하고, malformed operation_id의 400 기대 1개가 실패했다. 실제 기존 opaque 정책은 404였으므로 코드를 완화하지 않고 정확한 404 거절 기대와 array/대문자 거절 assert로 수정했다.
- 그 뒤 만료 미수거 export 1개와 실제 CLI 4개를 추가해 당시 이 파일의 회귀는 28개였다. 아래 전체 회귀의 오류 상태 분류 수정과 단독 회귀 3개를 추가해 현재 31개다. 최종 실제 Linux 결과는 부모의 002 Report에 통합한다. 이 메모의 작성만으로 미실행 회귀를 통과했다고 주장하지 않는다.
- root 세 원본 전체 텍스트 대조는 모두 동일했다. git-readonly diff --check는 exit 0이며 기존 다른 dirty 문서의 LF→CRLF 안내만 출력했다.

실제 운영 DB migration, 삭제, export/apply, timer 설치/활성화, 실제 upstream 모델 호출 및 운영 배포는 수행하지 않았다.

### 전체 회귀에서 확인한 오류 상태 분류 수정

부모가 실행한 Linux 전체 회귀에서 `test_first_error_cause_and_rejected_chunk_ack_are_preserved`와 `test_maintenance_full_global_gate_cleanup_does_not_open_equipment_db`가 기존 `failed` 기대와 실제 `cancelled`의 불일치를 검출했다. `guard_finish()`가 trash/purge뿐 아니라 cancel=1인 일반 오류/점검 작업도 처리하면서, 기존 Store.finish의 최초 오류 코드 기반 판정을 일괄 cancellation으로 바꾼 것이 원인이었다.

기존 fixture나 기대값을 완화하지 않고, guard_finish가 보존된 job.error_code를 기준으로 USER_CANCELLED/AUTH_EXPIRED는 cancelled, 다른 원인은 failed로 확정하도록 수정했다. 최초 error/error_code는 COALESCE로 보존하며 unknown은 recovery_required 점유를 유지한다. released guard의 재보고는 이미 저장된 failed/cancelled를 반환하고 점유를 다시 열지 않는다. 본문이 없는 purged guard의 기존 cancellation ACK는 유지한다.

단독 회귀는 일반/점검·잘못된 응답 실패의 최초 원인과 failed 상태, user/auth cancellation, unknown→known→늦은 unknown의 상태/그룹 점유를 검증한다. `lifecycle.py` 모듈 EN은 rev.2로 증가하고 핵심 guard finish 계약 ID를 추가했다. 부모 소유 `test_multi_provider_ai.py`는 읽기만 했으며 수정하지 않았다. 부모의 최종 재검증은 표준 SQLite pragma를 유지하는 `--tmpfs-fixtures` 격리 실행으로 수행할 예정이다.

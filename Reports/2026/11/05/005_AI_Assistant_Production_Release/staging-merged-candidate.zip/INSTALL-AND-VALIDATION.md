# 1~7번 및 공간 절약 배치 후보 통합·검증 안내

이 디렉터리는 승인된 Staging 구현 결과다. `overlay/`의 상대 경로는 프로젝트 root의 경로와 대응한다. 실제 운영 반영은 별도 단계이며, 파일 일부만 배포하거나 v4를 모르는 코드와 혼용하지 않는다.

| 항목 | 핵심 후보 |
| --- | --- |
| 1 표 | 사용자 JS/CSS의 안전한 DOM 표 renderer·행/열 상한·원문 표시·스트리밍/스크롤 보존 |
| 2 조회 오류 | policy의 공통 정규화, Domain/HTTP의 같은 검증, chat/probe 목적별 목록·문맥·진단 권한 |
| 3 짧은 이름 | 연결 이름/모델 표시 이름과 별도 capability·비활성 사유 |
| 4 관리자 메뉴 | `__init__.py`의 충돌 검사/멱등 reparent, app 자식 메뉴의 상위 grant·기능 필터 |
| 5 공통 UX | 관리자 native dialog/기존 overlay·직렬 조작·불명확 결과 조회·probe 단계/종료 안내 |
| 6 옛 화면 | 폐기 안내·API/static/gateway 차단 후보, Nginx deny 예시·11개 공개 자산 회수 manifest·보호 키 의존성 분리 |
| 7 휴지통 | v4 Store/lifecycle/API/UI, 점유 원장 분리·UTC 30일·복구/재이동·직접 삭제·원장·CLI/timer·삭제 결정 복원 대조 |
| 후속 배치 | 모바일 한 줄 제목·넓은 화면 내부 헤더 제거·composer 모델/새로고침/추론·모델 최대 136px·조건부 상태/지원 사유 |

기존 Python/Flask/requests/cryptography와 Vanilla JS를 사용하며 새 제품 의존성은 추가하지 않았다. 표 parser는 지원 범위를 제한한 DOM renderer이며 전체 GFM 구현으로 간주하지 않는다. 조회 도구의 원래 인자는 감사에 남기고 실행 인자만 정규화한다.

## 재현

Windows에서는 소스 구문/정적 검사와 source packaging만 수행한다. 앱/동작 시험은 기존 승인 SSH alias `eqmgmt-backup`에서 메모리로 전달한 소스와 임시 DB·가짜 HTTP/SSE 모델·loopback Chromium으로 실행한다. 운영 앱을 import하거나 실제 업무/AI DB·외부 모델을 열지 않는다.

```powershell
$env:PYTHONUTF8='1'
$env:PYTHONIOENCODING='utf-8'
& 'C:/Users/nkhst/AppData/Local/hermes/tools/python-3.14.9+20261021-win32-x64/python.exe' 'Staging/20261105-ai-ux-trash/overlay/tests/run_assistant_fixture.py' --browser --summary-only --tmpfs-fixtures --artifact-dir 'Reports/2026/11/05/004_AI_Assistant_Compact_Layout_Staging/screenshots-new-run'
```

`--artifact-dir`는 Reports 아래 **존재하지 않는 새 디렉터리**만 허용한다. 스크린샷은 승인된 검증 도구가 만든 합성 화면 산출물이며 실제 사용자 대화가 아니다. `--tmpfs-fixtures`는 서버의 전용 임시 tmpfs 디렉터리를 사용한다. SQLite WAL/FK/synchronous 설정은 바꾸지 않으며, 측정값은 기능 검사 시간이다. 디스크 내구성·전원 장애·운영 성능 시험으로 해석하지 않는다. 과거 수치나 중복 import된 TestCase를 새 고유 통과 수로 집계하지 않는다.

공간 절약 검증은 기존 표/휴지통/모델 흐름과 반응형 치수·조건부 안내를 함께 실행한다. `tests/compact_measure_browser_fixture.py`는 같은 초기 저장 표/Qwen/medium 상태에서 본문·컨트롤 치수를 측정하는 별도 뷰이며 기능 검사 개수에 중복 집계하지 않는다. 변경 전 `before-layout.json` 및 `screenshots-before/`와 구현 후 수치를 비교한다. 실제 스마트폰 키보드·브라우저 자체 확대와 동등 폭/높이 재배치 검증의 범위는 최종 보고서에서 구분한다.

## 향후 운영 반영 순서

1. 승인된 코드와 설정/메뉴/DB 일관 백업을 준비하고 신규 접수 제어·기존 자체 요청의 정상 종료 여부를 확인한다. 공유 Strata나 다른 서비스 요청을 취소하지 않는다.
2. v4 지원 코드·worker·점유 원장·API/UI를 같은 단위로 적용한다. 시작 시 v3→v4 가산 migration과 기존 데이터/예약/원장/단일 그룹 점유를 검증한다. 구버전 worker와 부분 혼용하지 않는다.
3. 관리자 메뉴 reparent는 정확한 코드/URL/부모 충돌 검사를 통과한 행만 대상으로 한다. 기존 이름/순서/grant를 보존한다. 새 API 연결과 키가 옛 Nginx include 없이 유지되는지 확인한다.
4. 새 AI 회귀와 실제 승인된 연결 smoke 확인 후 옛 Nginx 전용 deny 설정을 검사/reload하고, `overlay/docs/strata-retirement-manifest.json`의 정확한 공개 자산만 회수한다. license/Git 이력·공유 서비스/키는 보존한다.
5. private `USER_AI_DATABASE`와 `USER_AI_DATABASE_EPOCH`를 앱/worker/정리 도구에서 일치시킨 뒤 retention user service/timer를 설치한다. 기존 worker.env에는 DB 경로가 없을 수 있다. timer는 v4 검증 후에만 활성화하며 CLI는 v3를 거절한다. 기본 한 실행은 25개×4배치로 제한하므로 대량 만료/오류/중단 뒤에는 여러 주기로 차례 정리한다. 만료 항목의 열람/복구 차단은 이 물리 정리 backlog와 별개로 즉시 적용된다.
6. AI DB를 복원할 때는 최신 삭제/만료 결정을 DB 밖 private ledger로 먼저 보존하고, 복원한 v4 DB에 대조·재적용·정합 검사 후 서비스한다. 자체 요청 종료 확인·프로세스 정리·외부 epoch 변경이 선행된다. 최대 10,000개/8MiB 범위가 넘으면 조용히 생략하지 않고 중단하므로 별도 이관 절차가 필요하다.

코드 복귀는 timer를 중지하고 v4 상태를 이해하는 호환 코드로 수행한다. 영구삭제를 rollback으로 복구할 수 있다고 안내하지 않는다. 대화 삭제로 이미 확정된 장비 변경·업무 파일·감사 로그·실행 영수증·CSV 감사 원본·공유 프로바이더를 지우지 않는다.

자세한 기존 1~7번 구현 경계는 세 `notes-*.md`와 후보 `overlay/docs/ai-assistant.md`, `overlay/docs/strata-integration.md`에 있다. 기존 고정 검증은 Report 002, 공간 절약 병합 후 새 후보의 검증 수치/스크린샷은 Report 004를 기준으로 한다.

# 사용자 AI 채팅 UI 구현 인계

담당 범위는 승인 Plan 001의 1·3·7번 사용자 화면이다. 일반 bootstrap은 recorder 정상(PID 11268), profile `legacy/runtime-thread-id-conflict`(`verified=false`), governance validate pass였다. 해당 UI/security/delete/restore/handoff context의 전체 23개 노드를 직접 읽었고 신규 fixture 경로 추가 후에도 같은 context pack을 확인했다. 부모의 Task/Report 002 구현 전 Validation 1~8을 승계했다. 모델 실행 속도 Fast 적용은 도구로 검증하지 못하므로 보장하지 않는다.

## 산출물

- `overlay/static/js/equipment_ai.js`
- `overlay/static/css/equipment_ai.css`
- `overlay/templates/equipment_ai.html`
- `tests/test_equipment_ai_ui.js`
- `tests/assistant_ui_browser_fixture.py`

원래 root 소스는 읽기 전용으로 사용했다. 후보 세 파일은 원문을 JSON으로 읽은 뒤 structured `apply_patch` Add File로 복사하고, 이후에도 structured patch만 사용했다. 기존 dirty 파일과 다른 담당 파일은 수정하지 않았다.

## 실제 구현

DOM 기반 제한적 Markdown 렌더러에 `table/thead/tbody/th/td`, 좌·중앙·우 정렬, escaped pipe, 빈 셀/누락 셀, backtick/tilde 코드펜스와 인라인 코드를 추가했다. HTML은 해석하지 않고 기존 허용 앱 경로 링크만 유지한다. 전체 GFM 지원은 아니다. 표 헤더/구분 행의 열 수가 같아야 하며 표 행에는 unescaped pipe가 있어야 한다. 스트리밍 마지막 미완성 줄은 문단으로 보존하고 종료 때 최종 표로 갱신한다. 표는 40열/200행까지만 DOM 셀을 만들며 초과/추가 셀은 명시적 전체 원문 펼침으로 보존한다. 원래 메시지 저장 본문은 변경하지 않는다.

표의 가로 스크롤과 focus, 긴 표 원문의 펼침/스크롤을 갱신 뒤 복원한다. 답변 안의 텍스트를 선택한 동안 DOM 교체를 미루고 selection 해제 시 마지막 결과를 렌더한다. 기존 message/details 노드는 계속 사용하여 추론 펼침을 보존하고, 자동 추론 접기는 turn 최초 답변 때 한 번만 적용한다. 하단을 보던 독자만 새 출력으로 이동하고 다른 독자의 세로 위치는 유지한다.

모델 옵션은 `연결 이름 / 표시 모델 이름`으로 표시한다. 기능은 기존 별도 status에, 사용 불가 모델 사유는 별도 접근 가능한 펼침 목록에 표시하며 비활성 option은 유지한다. 확인되지 않은 양자화/호출 ID를 표시하지 않는다. opaque 모델 ID·저장된 추론 설정·접수 당시 출처는 그대로 사용한다.

최근 대화와 휴지통은 각각 독립 cursor/cache/request generation을 가진다. 갱신은 이미 불러온 항목이 나올 때까지 페이지를 따라가 stale 항목을 제거하고 이전 페이지 접근을 보존한다. 휴지통에는 서버 이동·만료 시각과 대략 남은 일수를 표시한다. 열람은 읽기 전용이며 composer/모델/추론/파일/확인 실행을 잠근다. 복구는 취소된 요청/확인 카드를 재실행하지 않는다. 정상 목록의 이동, 휴지통의 복구/영구삭제, 선택 대화의 동일 액션을 제공한다.

부모의 기존 mobile/desktop fixture가 찾아낸 more-load/background-refresh 경합도 보완했다. background reset이 more 응답보다 먼저 request generation을 올리면 사용자가 명시적으로 읽은 older page를 버릴 수 있었다. view별 목록 요청을 pending promise 큐로 직렬화해 background refresh가 more 완료 뒤의 depth/loaded-ID 경계를 사용하게 했다. 삭제/복구 동기화 GET은 생략하지 않는다. History EN rev.2와 cursor 응답 보류 중 focus recheck를 강제하는 실제 경합 fixture를 추가했다.

native dialog는 대상 제목·30일 보관·영구삭제 복구 불가 범위를 명시하며 파괴적 확인의 최초 focus는 취소다. 짧은 처리 동안 중복 조작을 잠그고 완료/실패/결과 불명확을 구분한다. ACK 뒤 GET 실패는 성공+화면 갱신 실패로 표시한다. 불명확 POST를 자동 재전송하지 않으며 GET 현재 상태 확인부터 수행한다. 상태가 확정되지 않으면 사용자가 별도 확인한 뒤 같은 operation ID/revision으로만 다시 보낼 수 있다. purge의 GET 404를 성공 증거로 단정하지 않는다. BroadcastChannel(불가 시 storage hint)·focus·visibility·주기 검사에서 인증된 서버 상태를 다시 읽어 다른 탭 변경을 반영한다. 브라우저 hint 자체를 권한/상태 근거로 사용하지 않는다.

API 계약은 부모 제안 그대로다: 목록/메시지의 `view=active|trash`, conversation의 `lifecycle_revision/is_deleted/deleted_at/purge_after`, POST `trash|restore|purge`의 `{lifecycle_revision,operation_id}`. trash/restore ACK는 conversation을, purge ACK는 `purged:true`를 요구한다. 기존 CSRF/계정 context/동일 출처 경계를 유지한다.

Store의 동일 operation 재전송 계약을 읽기 대조해 `replayed:true`는 예전 동작을 다시 적용하지 않고 **현재** metadata를 반환하는 점도 반영했다. action 이름으로 view를 정하지 않고 `purged/is_deleted`와 후속 GET 현재 상태를 사용한다. 예전 trash operation이 복구 뒤 도착하면 현재 active로 유지하고 modal에 기처리 요청/현재 정상 상태를 설명한다. 예전 operation 뒤 이미 purge된 경우에도 tombstone의 `purged:true`를 따른다. lifecycle EN rev.2에 이 계약을 적었다. 신규 fixture에는 지연 원 요청 처리→다른 탭 복구→동일 예전 operation 재전송과 현재 상태 보존을 추가했다.

## 검증 상태

- Windows `node --check overlay/static/js/equipment_ai.js`: exit 0.
- Windows `node --check tests/test_equipment_ai_ui.js`: exit 0.
- root 세 소스에 대한 git diff: 비어 있음.
- Windows `python`은 설치 스텁 응답(exit 1)이라 AST 검사를 수행하지 못했다. Python AST와 실제 브라우저 행동 검증은 부모의 승인된 Linux 격리 실행으로 인계했다.
- Windows에서 앱/브라우저 fixture/행동 검증은 실행하지 않았다.
- 부모의 Linux round1에서 기존 채팅 UI 회귀는 desktop 32개/mobile 33개 검사를 통과했다. 신규 8화면은 최초 10개 검사(표 의미 구조·정렬·escaped/empty/missing 셀·XSS 등) 뒤 `incomplete-delimiter-remains-text`에서 모두 실패했다. 원인은 fixture가 미완성 streaming 검사에 `{streaming:true}`를 빠뜨린 것이었다. 해당 인수를 추가하고 텍스트 보존도 검사하며, 최종 텍스트에서는 짧은 delimiter도 유효한 표임을 별도 검사하도록 고쳤다. 구현을 좁히거나 검사를 제거하지 않았다. [공식 GFM 표 규격](https://github.github.io/gfm/#tables-extension-)의 delimiter/선택적 외곽 pipe 계약을 확인했다. 새 snapshot 재검증은 대기 중이다.
- 부모의 실제 Tailwind 테마 round2에서 신규 8화면은 32개 검사까지 진행한 후 결과 dialog focus assertion에서 실패했다. `dialogFocus`가 body인 경우 visible/enabled만 검사해 focus 불가능한 body를 선택한 것이 원인이었다. helper를 실제 focus 가능한 요소(button/a/input/select/textarea/tabindex)로 제한했다. 기존 desktop 채팅 32개는 pass였고, 기존 mobile 채팅은 이전 목록 대기 timeout으로 부모의 추가 진단을 기다린다. round2 PNG는 로컬에서 읽기 전용으로 확인했으며 이 확인을 Windows 앱 실행으로 세지 않는다.
- 부모 round4에서 신규 8화면은 각 58~59개 검사를 통과했다. 이 snapshot 뒤에 추가한 receipt/current-state와 목록 요청 직렬 큐·강제 경합 회귀는 새 snapshot 재검증이 필요하다. 기존 채팅 fixture의 more timeout trace가 실제 UI 경합을 확인해 위 큐 보완으로 처리했다. 과거 통과를 최신 후보의 최종 통과로 재사용하지 않는다.
- 부모 round5 Linux 브라우저 검증은 기존 채팅 32/33개와 신규 8조합 각 62~63개를 포함한 전체 16뷰 757개 검사를 모두 통과했다(목록 큐·receipt 보완 포함). 마지막 표 재열기 screenshot fixture와 “장비 삭제”로 명확히 한 footnote는 부모의 최신 combined 최종 검증으로 확인한다. 이후 코어/fixture는 동결했다.
- 이후 combined에서 backend 178개와 신규 사용자 8뷰는 통과했으나 legacy desktop의 첫 전송이 발생하지 않는 반례가 확인되어 동결을 해제했다. 원인은 `open()`이 hydration 뒤 sidebar 목록 큐까지 await해 composer를 불필요하게 잠근 점이었다. 목록 갱신을 독립 background로 옮기고 Client EN rev.7/OPEN 계약을 기록했다. 목록 GET을 보류한 채 composer 준비·실제 submit POST 도달(합성 422, 실제 저장 없음)·초안 유지·unchanged focus의 같은 message DOM 및 진행 stream/job 보존을 검사하는 fixture를 추가했다. 최신 두 JS node syntax는 exit 0이며 이 새 snapshot은 부모의 Linux 재검증 대상으로 인계한다.

신규 Python fixture는 `run_browser(project, assets)`로 list 결과를 반환하며 `assets['tests/test_equipment_ai_ui.js']`를 사용한다. 없을 때만 project 아래 Staging fixture 파일을 읽는다. 기본 매트릭스는 390/430/820/1440 × light/dark다. 기존 frame을 렌더하고 loopback synthetic transport만 사용한다. 결과에는 status/checks/width/theme/exit_code와 선택 screenshot을 포함한다. 두 번째 실제 app iframe과 BroadcastChannel을 사용해 stale revision과 읽기 전용 전환을 확인한다. 별도 서버/모델/실제 DB에는 연결하지 않는다.

round1 시각 검토에서 공통 frame의 Tailwind CDN 차단과 onerror fallback 미요청이 확인되어, fixture에서 CDN src를 기존 로컬 `static/js/tailwindcss.js`로 직접 치환했다. 실제 Tailwind preflight를 사용하므로 수동 font-size/reset 주입은 제거했다. 공통 session timer가 서버 설정을 다시 적용하므로 fixture `/api/user_settings`도 Referer의 요청 theme와 같은 synthetic `settings.theme`를 반환한다. 이들은 fixture 검증환경 보완이며 앱의 배경/테마 규격을 바꾸지 않는다.

새 fixture는 과거 표·정렬·escaped/empty/missing 셀·펜스·미완성 streaming·XSS·긴 표 상한/전체 원문·선택·스크롤·테마·목록 페이지·독립 cursor·읽기 전용·purge 취소·복구 무재실행·ACK 뒤 GET 실패·분실 ACK의 GET 확인·동일 ID 수동 재전송·두 탭·stale 409·실패·중복 클릭·실제 poll 표/추론·기존 CSV·CSRF·purge idempotent receipt·만료 직전 UI의 서버 거부를 검사한다. 아직 실행 전인 fixture를 통과로 세지 않는다.

기존 채팅 fixture의 총 button 개수는 이제 대화별 휴지통 버튼도 포함하므로 이전 대화 수 검사는 `.ai-conversation` selector로 보정해야 한다. 부모가 원래 fixture를 소유하고 이 보정을 진행한다.

## 인계 시 남은 점

부모가 Linux 회귀를 실행하는 동안 코어 후보 편집은 동결/인계한다. round1 snapshot 후 부모와 합의해 결과 modal 닫힘 직후 잠금 해제·재렌더가 끝나야 보이는 활성 focus 대상으로 복귀하도록 보완했고, fixture에 focus assertion을 추가했다. `ASSISTANT.UI.PROPOSAL.CARD`는 read-only 실행 금지 계약을 반영해 EN rev.2로 올렸다. 실제 최종 UI 검증 수치는 부모 실행 결과로 보완해야 한다. 새로운 EN 기준 주석은 구현/기술 계약만 작성했고 KO 본문·revision 동기화나 comment-sync baseline 수용은 대신 하지 않았다. 운영 병합·서비스 배포·실제 대화 삭제는 수행하지 않았다.

공유 native dialog의 queued old close 반례도 읽기 대조했다. 이 화면은 close notification listener를 등록하지 않으며 finishDialog가 resolve 참조를 비운 뒤 close한다. 따라서 옛 close notification이 새 resolve를 실행할 경로가 없다. 실제 같은 notification 주입이 새 확인 모달을 닫거나 POST하지 않음을 fixture에서 추가 검사한다.

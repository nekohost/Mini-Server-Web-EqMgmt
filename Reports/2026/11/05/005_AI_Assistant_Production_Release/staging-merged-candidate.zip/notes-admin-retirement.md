# 관리자 UX·메뉴·기존 Strata 폐기 후보 인계

작업: `STAGING-20261105-AI-UX-TRASH`, 작업자 Codex의 `admin_retirement` 하위 작업. 사용자 승인 범위는 Staging 구현·검증이다. 원본 root 소스·실제 DB·Nginx·서비스·API 키는 변경하지 않았다. 추가 재위임은 하지 않았다.

## 진입 확인

- recorder ensure 정상, 기존 watcher PID 11268 재사용.
- 이 작업자의 profile은 legacy / `runtime-thread-id-conflict`, model 미검증이었다. 부모의 `runtime-session-mismatch`와 구분한다. 요청된 모델 및 reasoning 설정과 실제 runtime 검증을 혼동하지 않으며 Fast 설정은 도구에 없어 보장하지 않는다.
- governance 1.8.1 validate: manifest 44 nodes, errors 0, warnings 0.
- catalog 뒤 구현/frontend/ux/responsive/authorization/authentication/security/secret/migration/review/handoff/continue-work intent와 실제 후보/읽기 전용 참고 경로로 context 성공. 3개 pack의 30개 고유 노드 및 Codex capability, 주석 규격을 모두 읽었다.
- 승인 Plan001 전체, Task002/Report002의 구현 전 Validation1~8을 읽고 분담을 승계했다. 공유 Task/Report는 직접 편집하지 않는다.

## 실제 후보

- `overlay/app.py`: 원본 전체를 structured Add File로 복사했다. children 메뉴 API에서 상위 grant를 확인하고 메인과 같은 Strata/assistant visibility filter를 적용한다. import/install 설명을 폐기 계약에 맞췄다. 원본 대비 변경은 이 통합 지점에 한정한다.
- `overlay/utils/strata_integration.py`: old menu 등록을 무동작으로 전환하고 메뉴는 모든 역할에서 숨긴다. `/ai`, `/ai/console`은 현재 로그인 뒤 `strata_retired.html`을 렌더한다. `/strata`, `/strata/*`, `/api/strata/*`, `/_eqmgmt_strata_auth` 및 전용 static은 unconditional 410이며 upstream client·old setting 읽기를 제거했다. 예전 helper import는 fail-closed 호환 함수로 유지한다.
- `overlay/templates/strata_retired.html`: 새 assistant 링크와 기존 browser history 보존 설명. iframe/bridge/vendor/old namespace 주입 없음.
- `overlay/static/js/equipment_ai_providers.js`, CSS, template: 기존 공통 로딩 재사용, 모든 관리 조작의 공통 native dialog/잠금·aria-busy·stable focus 복구·모바일 하단 피드백. 이름/키는 text DOM으로만 처리한다. saved ACK/GET 실패/POST unknown/409를 분리하고 GET 결과 확인과 명시적 확인 상태 해제를 제공한다.
- 기능시험은 client_key와 owner-bound GET probe lookup으로 접수 유실을 조회한다. ACK 뒤 overlay를 닫고 queued/running/draining 상태를 별도로 추적한다. `done`만 성공이다. 실패/취소/recovery_required/조회 오류를 구분하며 job ID를 세션 저장소에 보관해 조회를 재개한다. 모델 총시간 취소·공유 초기화·POST 자동 재접수 없음.
- `overlay/tools/deploy_user_ai.py`: prepare-key의 `/etc/nginx/private/strata-upstream-key.conf` 의존성을 제거했다. 기존 private USER_AI config는 bytes/owner/mode를 보존하고 입력을 읽지 않는다. 신규 config만 명시적 root/서비스 계정 소유0600 key-file·private parent·symlink/크기/한줄 검사를 통과해야 생성한다. API 키 삭제/회전 없음.
- `overlay/tools/deploy_strata.py`, `write_strata_nginx_key.py`: 옛 설치/키 쓰기 helper는 비정상 종료하는 폐기 안내로 바꿨다. 기존 추적 ID는 유지하고 EN revision을 높였다. 실행 시 설정/키/DB/서비스 변경 경로가 없다.
- `overlay/systemd/nginx-strata.conf.example`: 해당 장비관리 HTTPS server 전용 deny snippet 후보. upstream proxy/auth/key include 없음. 실제 Nginx 적용은 하지 않았다.
- `overlay/docs/strata-integration.md`, `strata-retirement-manifest.json`: 적용 순서/복구/whitelist 11개 공개 UI 파일/라이선스·Git 이력·새 AI·공유 Strata·old private key·localStorage 보존을 명시했다. 실제 파일 삭제는 없다.
- `overlay/tools/check_strata_static.py`, `tests/test_strata_integration.py`, `test_admin_release.py`, `test_strata_bridge.mjs`, `admin_providers_browser_fixture.py`: 긍정적 옛 설치/bridge 테스트를 폐기 계약으로 대체하고 관리자 metadata·권한·키·비동기 UX 회귀를 추가했다. Linux memory runner용 SOURCE_APP/CANDIDATE_ASSETS/CANDIDATE_FILES를 사용한다. browser fixture는 SCRIPT와 run_browser(project,assets)를 제공한다.

메뉴 seed/reparent와 일반 사용자 settings filter, GET `/api/admin/ai/probes?client_key=32hex`는 부모 소유 `utils/ai_assistant/__init__.py`에 요청해 부모가 통합했다. parent/root 파일 소유권을 침범하지 않았다.

## 검증 근거와 미실행 범위

Windows에서 `.venv/Scripts/python.exe -B overlay/tools/check_strata_static.py` 실행은 성공했다: Python AST9, JavaScript node--check2, Jinja2, manifest 제거 whitelist11; application_started=false/database_opened=false/behavior_tests_run=false. 별도 관리자 JS node--check와 Python AST5도 통과했다. Windows에서 앱 import/기동·행동 테스트를 하지 않았다.

부모 Linux runner가 새 테스트·모듈·asset·CANDIDATE_FILES 및 browser fixture를 memory payload로 묶는다. Linux 실제 결과는 부모가 실행해 확인하며, 이 시점에 임의의 통과 수치를 기록하지 않는다. 새 fixture는 native dialog를 실제로 닫고, 느린 저장/중복 submit/전환 잠금/모바일 하단 focus/키 비노출/모델 저장/수동 등록/조회 실패/409/ACK뒤GET실패/POST유실/시험 접수유실/큐·진행·조회재개/각 terminal/폐기 확인을 다룬다. 기본 admin desktop430와 추가390light/430dark/768light/1440dark를 지원한다.

## 구현 후 Validation1~8 자체 교차 검토

1. 거버넌스: structured apply_patch만 사용했다. 원본 dirty 변경을 보존했고 후보 외 파일을 쓰지 않았다. DB/query 실행·실제 서비스·키 조작은 하지 않았다. 기존 MINI-COMMENT ID/EN 계약 변경 revision을 높이고 KO를 대신 번역하지 않았다.
2. 의도: 4번 메뉴 이전은 부모와 통합, 5번 관리 UX, 6번 구형 UI/gateway/도구/키 의존성 폐기를 구현했다. 신규 assistant/adapter/USER_AI 키/worker/공유 Strata는 별도 보존 경계로 유지한다.
3. 논리: 상태 변경 중 controls를 inert+disabled로 잠근다. disabled 상태의 중복 requestSubmit도 payload 생성 전에 차단한다. GET이 실패하면 현재 목록을 교체하지 않고, POST는 자동 재전송하지 않는다. 긴 모델 작업 중 UI 잠금/DB writer/전역 취소를 추가하지 않는다.
4. 운영 영향: 앱 차단과 실제 static-serving Nginx 차단이 모두 필요하다. 후보 snippet을 적용하기 전 실제 server/config 확인과 백업/nginx -t/reload 검증이 남아 있다. manifest 파일은 검토·배포용이며 Staging에서 원본 파일을 삭제하지 않는다.
5. 보안/예외: 기존 실제 로그인·세션 재검사와 관리자/API 권한을 유지한다. 일반 사용자 잘못된 settings grant는 목록/서버 양쪽에서 막는다. private bootstrap은 명시적 보호 파일만 읽고 secret을 응답/모달에 표시하지 않는다. 옛 gateway는 flag·grant·CSRF와 무관하게 차단한다.
6. 복귀: 원본은 미변경이다. 운영 적용 시 코드/config/metadata 개별 사본으로 복귀하며 DB 전체 과거 덮어쓰기와 키 회전을 하지 않는다. lifecycle v4 호환 복귀·timer는 부모 통합 조건이다.
7. UX: native dialog의 이름/설명·Escape/확인·stable focus 복구 및 현재 스크롤과 독립적인 top-layer 표출을 구현했다. 확인 상태 해제는 GET만 수행하며 불확실한 POST의 실패/성공을 허위 확정하지 않는다. 실제 크기·dark/light 결과는 Linux Chromium 검증으로 확정한다.
8. 메타: runtime conflict와 검증 한계를 공개했다. 실제 수행한 정적 검사와 아직 실행하지 않은 Linux 행동 검증을 구분한다. 승인 없는 운영 반영·공유 데이터 변경·추가 위임은 하지 않았다.

## 제한·부모가 이어 확인할 사항

연결 생성/모델 저장 API에는 operation receipt가 없다. ID/revision/현재 목록을 읽어도 특정 유실 POST의 처리와 secret 값 일치를 원자적으로 증명할 수 없으므로 결과 확인 UI는 이를 설명하고 자동 재생성/재전송을 금지한다. 새 기능시험만 기존 idempotent client_key로 owner-bound 접수 확인이 가능하다.

기존 `docs/ai-assistant.md`의 prepare-key/root Nginx key·v3 설명은 부모 통합문서에서 새 계약으로 갱신해야 한다고 메시지로 인계했다. 운영 URL·Nginx·private input·실제 provider 연결의 smoke는 이번 Staging 변경으로 수행됐다고 보고하지 않는다. vendor 공개파일 최종 회수와 메뉴/grant 정확한 행의 최종 삭제는 별도 배포/참조 검토 단계에 남긴다.

## Linux round1 반례 수정

부모가 실제 Linux Chromium 6개 관리자 화면(기본1440/430, 추가390light/430dark/768light/1440dark)에서 첫 7개 assert 통과 후 `focus-restored-after-render` 실패를 보고했다. 원인은 native `method=dialog`가 `open`을 먼저 해제하고 `close` 이벤트를 나중 task에 전달하는데, focus 복구가 그 이벤트에만 매여 있었기 때문이다. 모달이 닫힌 시점에 숨은 dialog 버튼이 잠시 activeElement로 남을 수 있었다.

`ASSISTANT.PROVIDERS.CLIENT.DIALOG` EN revision을 2로 높이고 submit/Escape의 기본 닫기를 명시적으로 처리해 `dialog.close()` 직후 같은 이벤트 안에서 focus를 복구하도록 수정했다. 외부 close의 fallback은 유지하며 cleanup/resolve/focus는 한 번만 실행한다. fixture의 `document.activeElement.id === 'provider-save'` 기준은 그대로 유지했다. Windows에서는 node syntax와 기존 정적 checker만 재검증하며 실제 개선 여부는 부모 Linux 재실행으로 확인한다.

같은 round1의 dark 시각 검토에서 fixture가 CDN을 CSP로 차단했고 공통 Tailwind fallback이 요청되지 않은 점을 부모가 발견했다. 새 admin fixture는 bundled `/static/js/tailwindcss.js`를 직접 로드한다. 또한 실제 session_timer의 GET 설정 복원이 빈 settings를 system(light)로 덮어쓰던 fixture 문제를 고쳐 요청된 dark/light를 합성 preferences에도 일치시켰다. 코어 배경은 변경하지 않았다. 실제 dark class/body RGB(15,23,42 또는 241,245,249), body 글자 대비 및 결과 dialog 글자 대비 4.5 이상을 수치로 검사하고 측정값을 결과 JSON에 남긴다. 기본 focus 조건은 유지하며 일반 form-name 기반 입력 focus와 결과 확인 뒤 사라지는 버튼의 fallback도 보강했다.

## Linux round2 반례 수정

부모의 실제 round2에서 1440dark는 전체31 checks를 통과했고 body RGB와 dialog 대비 약5.895도 확인됐다. 좁은 화면은409 이후 확인 흐름에서 대기, 768light는 POST 유실 후 조회 결과를 불러오는 단계에서 실패했다. 기본 wrapper의14초 virtual-time budget 종료도 별도 관찰됐다.

코어 경합 원인은 직전 `dialog.close()`가 예약한 close 이벤트가 다음 모달을 다시 연 후 도착할 수 있다는 점이었다. 새 모달의 close listener가 직전 이벤트에 반응해 열린 확인 창의 Promise를 미리 취소로 종료하고 submit listener를 제거할 수 있었다. DIALOG EN revision3에서 `dialog.open`인 동안의 close 이벤트는 무시해 실제 닫힌 모달만 resolve/cleanup한다. 동기 focus 복귀는 그대로 유지한다. fixture는409 뒤 새로고침 확인 창에 지연 close 이벤트를 직접 전달하고, 그 후 실제 확인으로 GET 갱신이 완료되어야 하는 회귀를 추가했다. 기존 POST 유실/키 비움/자동 재전송 금지 기준은 완화하지 않았다. fixture 실행 budget은 모델 실행 제한과 무관하며 부모가 별도 조정할 수 있다.

## Linux round4 wrapper 진단

부모가 새 admin fixture의390light/430dark/768light/1440dark 모두32 checks 통과, 실제 테마와 dialog 대비 약5.895를 보고했다. 같은 SCRIPT를 기존 공통 wrapper에 주입한1440/430만0 checks에서 대기 실패하여 이 단계에서는 코어를 변경하지 않았다. SCRIPT EN revision4는 provider 초기화 대기와 theme 대기를 구분하고, 실패 JSON에 provider-list text·root aria-busy·notice·현재 모달·최근5 API 경로/메서드/필드명·실제body RGB/dark/cache/system theme·로드된 관련 script·마지막 browser 오류를 제한적으로 남긴다. API key 값·본문·인증 헤더는 진단에 포함하지 않는다. 부모가 공통 wrapper의 합성 preferences를light로 맞추고 새 payload로 확인한다.

부모 round5에서는 전체16개 브라우저 뷰757 checks가 통과했고 관리자 기본1440/430 및 추가4뷰는 각32 checks, 테마 RGB와 dialog 대비도 정상으로 보고됐다. 이후 최종 combined는 backend178 tests가 통과했지만 기본1440에서만 간헐적인 frame-theme 실패가 재관찰됐다. 목록/aria-busy는 정상이고 light 설정·dark class=false인데 body는dark RGB, system media는dark였다. 이전 round5 성공을 이 최종 source의 성공으로 재사용하지 않는다.

SCRIPT EN revision5는 이 불일치를 분류하기 위해 `tailwind.config.darkMode`, config key/설정 script 존재, CSSOM의 body 관련 실제 선택자·미디어 조건/활성 여부·body 매칭 및 초기 frame script 오류를 함께 남긴다. 성공 조건에도 실제 공통 frame의 darkMode가class임을 추가해 system media 때문에 우연히 통과하지 못하게 했다. bundled Tailwind의 기본값은media이며 config가class인데 CSS가media이면 stale async compile 또는 다른 style 기여를, config 자체가미설정/media이면 frame 설정 미적용을 각각 구분할 수 있다. CSS/background·테마 기준·제품 코어는 변경하지 않았다. 공통 wrapper의 중복 user_settings route도 부모에게 읽기 진단으로 알렸다.

## 최종 fixture의 virtual transition settling

FRAME_DIAGNOSTIC 주입 뒤 부모의 legacy 집중 실행은4뷰 모두 통과했다(채팅32/33, 관리자33/33). 단일 최종 실패의 원인을 이 결과만으로 확정하지 않는다. 부모 요청에 따라 SCRIPT EN revision6은 실제 root body의 `transition-colors duration-200`이 headless 가상시간에서 중간값에 머무는 경우를 분리하도록 보강했다.

frame-theme 검사 전에 `body.getAnimations({subtree:false})` 중 body 자신을 대상으로 하는 유한한 background-color/color 전환만 `.finish()`해 최종 endpoint를 검사한다. CSS·class·media·transition duration·목표 색은 변경하지 않는다. 무한 animation이나 자식 요소 animation은 조작하지 않으며 잘못된 class/media의 최종 색은 여전히 정확 RGB/darkMode=class/대비 검사에서 실패한다. 처리한 property/원래currentTime/endTime/전후 배경을 제한된 진단 trace에 남긴다. 이는 **fixture의 virtual transition settling**이며 기존 간헐 실패의 원인이 transition이었다고 단정하는 기록이 아니다. 이번 수정은 admin fixture와 이 notes뿐이며 제품 JS/CSS는 불변이다.
